# Output format - Complex Analysis I, Module II

Reply in chat with exactly these two parts, in this order:

1. ONE fenced `json` block containing the complete Module II JSON. No comments,
   trailing commas, ellipses, placeholders, generator code or missing steps.
2. A short plain-text list titled `Not verified from the PDFs`. List each
   unverified claim, unresolved source inconsistency or missing coverage item;
   write `none` only if the full source/coverage audit actually passed.

Nothing else: no preamble, separate derivation inventory or extra code blocks.
Perform the exhaustive derivation inventory and card-to-source mapping privately.

Final structural checks:
- Keys: `meta`, `match`, `glossary`, `sections`.
- Exact title: `Complex Analysis I — Module II: Complex Functions, Mappings and Special Power Functions`.
- One section titled `Module II`; five sheets `ca-m2-unit-6` to
  `ca-m2-unit-10`, in order. Units 9 and 10 remain separate.
- Each source starts `Unit N · Zill & Shanahan §...`, with the correct N.
- All new IDs start `ca-m2-`; all referenced glossary IDs exist in this file.
- Every in-scope derivation, example subpart and prose working is complete.
  There is NO maximum derivation/card/step count that permits omission.
- Each derivation has a declarative JSXGraph `setup`, complete `steps`, valid
  `focus` names and allowed moves. Do not put raw SVG in `setup`.
- First step: no move. Later steps: one move, one top-level relation and a note.
- Quiz answers are valid and zero-based; numerical answers are JSON numbers.
- Settings match PROMPT.md, with empty date and sessions.
- Exclude the exact out-of-scope material named in PROMPT.md, even when it
  shares a PDF page with an included example.

The user will save the JSON as `data-ca-m2.json` and run the shared builder.
