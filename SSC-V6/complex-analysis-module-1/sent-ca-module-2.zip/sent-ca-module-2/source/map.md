# Verified Module II source map - Complex Analysis I (MAT5CJ303)

Authority: the Module II table in `syllabus.pdf`. Textbook: Zill and Shanahan,
*Complex Analysis: A First Course with Applications*, third edition.

The full textbook offset was verified against each section/continuation page:
**full-book PDF page = printed page + 14**. Each bundled cut has its own local
page numbering starting at 1. Use the printed footer to identify passages.

| Unit | Full-book PDF pages | Printed pages | Bundled file | Exact inclusion |
|---|---|---|---|---|
| 6 | 61-67 | 47-53 | `units/unit-6-complex-functions.pdf` | Section 2.1 prose through the continuation of Remarks on p.52. Include only named Problems 32 and 33 from the exercises on p.53. |
| 7 | 68-73 | 54-59 | `units/unit-7-complex-functions-as-mappings.pdf` | Section 2.2 through the complete solution of Example 4. Exclude Use of Computers on p.59. |
| 8 | 86-90 | 72-76 | `units/unit-8-power-function-z-n.pdf` | Start at 2.4 Special Power Functions, not the project above it on p.72; include all 2.4.1, through Example 4; stop at 2.4.2 on p.76. |
| 9 | 90-92 | 76-78 | `units/unit-9-principal-square-root-through-example-5.pdf` | Start at 2.4.2 on p.76; stop after Example 5(c) at the top of p.78. |
| 10 | 96 | 82 | `units/unit-10-principal-nth-root-functions-and-example-9.pdf` | Start at Principal nth Root Function, below the Example 8 continuation; include through the end of Example 9. |

Corrections relative to the earlier broad map:
- Unit 8 needs printed p.76: omitting it drops the general ray discussion and
  Example 4, both still in 2.4.1.
- Unit 9 is not all of 2.4.2: it stops after Example 5(c), before the following
  alternative-argument and inverse-function discussion.
- Unit 10 is the p.82 principal-nth-root passage and Example 9, not the entire
  remaining section. Examples 6-8 and pp.83-86 are not assigned to this module.
- Five unit PDFs are provided; Units 9 and 10 are deliberately separate.

Earlier Module I covered sections 1.1-1.5. Its data is the example/style reference.
No later-module sections are bundled or authorized by this map.
