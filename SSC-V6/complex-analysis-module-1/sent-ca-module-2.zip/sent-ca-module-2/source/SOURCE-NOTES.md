# Source-reading cautions

- Use the rendered PDF, not extracted text alone. Overbars, superscripts,
  radicals, minus signs and inequality endpoints may disappear in text extraction.
- In section 2.2 Example 3, printed p.58, the map is the conjugate of the
  product iz: `w = \overline{iz}`. It is NOT `w = iz` or `w = i\bar z`.
  Check the printed bar in both the question and the substitution line. This
  distinction determines both endpoint images and every sign in the solution.
- Named examples may start in one cut and end on its next page. In particular,
  section 2.1 Example 3 ends on p.50; section 2.2 Examples 1 and 3 continue;
  section 2.4 Example 2 continues onto p.75; Example 5(c) is on p.78.
- Section 2.4 Example 4 is on p.76 and belongs to Unit 8, despite sharing that
  page with the heading for Unit 9. Do not drop it or move it into Unit 9.
- Unit 10's p.82 starts with the end of Example 8. That material and Figure
  2.4.14 belong to the excluded preceding discussion. Begin at the explicit
  Principal nth Root Function heading.
- Keep the book's principal-argument convention from Module I, including open
  versus closed endpoints. Do not replace it with a different convention.
- Section 2.1 explicitly defers proofs of properties (5)-(8) to section 4.1.
  Distinguish a stated result, a definition and a proof actually in the source.
- If a diagram, caption and prose seem inconsistent, check the original visual
  page and the defining equations. State any unresolved inconsistency in the
  final verification list rather than silently choosing an unsupported result.
