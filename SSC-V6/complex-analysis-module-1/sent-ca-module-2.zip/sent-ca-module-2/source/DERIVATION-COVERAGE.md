# Required derivation and worked-solution coverage

This is a MINIMUM audit checklist, not permission to omit anything else in the
allowed textbook spans. Read the actual PDFs for all equations, subparts,
figures, ranges and intermediate reasoning. The prompt requires every in-scope
derivation, including workings that have no 'Derivation' heading.

Do not output this checklist instead of the cards. Privately map each item to
the actual card IDs and steps before delivering the complete JSON. There is no
fixed derivation count; split long results/methods into clear consecutive cards.

## Unit 6 - section 2.1, printed pp.47-53

- Function, image/value, domain, range, natural domain, and complex function:
  Definition 2.1.1. Distinguish domain of a FUNCTION from a plane-domain set.
- Example 1(a),(b), p.48: every given evaluation of f and g. Preserve overbars
  and other notation as visually printed; show all substitutions and arithmetic.
- The natural-domain example after Example 1: exclusion of the denominator's
  zeros for the rational function, including both excluded points.
- Unnumbered derivation of real and imaginary parts of the squaring function,
  equation (1), p.48, including expansion and collection of terms. Then equation
  (2), the general Cartesian description of a complex function.
- Example 2(a),(b), p.49: derive both real functions u and v in each part,
  without quoting the final pair or hiding the distributive expansion.
- Unnumbered example specified through u and v, p.49: include its evaluation at
  the stated complex point. Include the text's reference to Problem 32 and the
  exact problem statement from p.53, following the named-exercise rule.
- Definition 2.1.2 and equation (3), pp.49-50: complex exponential defined through
  its real/imaginary parts. Example 3(a),(b),(c), all working and approximations.
- Exponential notation, equation (4), p.50: show how the polar form becomes the
  exponential form from the section's definition. Include the source examples
  and why changing an argument by an integer multiple of 2 pi preserves z.
- Properties (5)-(8), p.50, are stated there; the book explicitly defers their
  proofs to section 4.1. Retain the properties as stated and do not pretend the
  later proofs are in this bundle. Include periodicity and the named Problem
  33 statement, with source-labelled working if you choose to solve that task.
- Polar-coordinate real/imaginary parts: equations (9)-(10), pp.50-51; the
  complete computation for the squaring function in polar coordinates.
- Unnumbered polar-defined function evaluated at the book's stated point,
  p.51: obtain the point's r and angle, substitute, and evaluate all terms.
- Remarks, pp.51-52: the comparison with real functions, and the two special
  types of functions, including the complex-valued real-parameter example.

## Unit 7 - section 2.2 through Example 4, pp.54-59

- Explain the two-plane representation and why a complex function's graph would
  require four real coordinates. Introduce images of sets, not only points.
- Example 1, pp.55-56: image of the given half-plane under the stated mapping.
  Derive u and v, translate the coordinate constraints, and include the boundary.
- Example 2, p.56: image of the vertical line under the squaring function.
  Derive equations (3)-(4), solve for the parameter, substitute into the other
  equation, expand the square and identify the parabola and its full range.
- Definition 2.2.1, p.57: parametric curves; the line parametrization, equation
  (6), and its coordinate interpretation. Do not just list parameter formulas.
- Line segment, ray and circle parametrizations, equations (7)-(10), p.58:
  explain how the endpoint/center/radius and parameter interval define each set;
  show the Cartesian-to-complex and trigonometric-to-exponential changes.
- Unnumbered mapping of a parametrized line, p.58: substitute z(t), perform
  the complex multiplication, identify the image and retain the parameter range.
- Equation (11), composition rule for the image of a parametrized curve.
- Example 3, pp.58-59: the source mapping contains a conjugation bar over the
  product iz. Preserve it! Derive the segment parametrization, apply the whole
  conjugation, simplify, and check both image endpoints and the parameter range.
- Example 4, p.59: every line from the semicircle parametrization to its image,
  equations (12)-(13); explicitly show the variable change and transformed
  interval, concluding with the image circle's center and radius.
- Stop before Use of Computers. No Mathematica/Maple content or later examples.

## Unit 8 - section 2.4 introduction and ALL 2.4.1, pp.72-76

- Power/polynomial context from the 2.4 heading onward; no section 2.3 project.
- Unnumbered squaring evaluation and the exponential-form derivation, equation
  (1), p.73. Distinguish the new modulus from the magnification factor and the
  new argument from the rotation angle. Preserve the source's special cases.
- Example 1, pp.73-74: image of the circular arc, with both the geometric
  modulus/angle method AND the alternative parametrization and variable change.
  Show all radius, angular interval and parameter interval calculations.
- Unnumbered semicircle/right-half-plane image discussion, p.74: include why
  the union covers the indicated image, both boundary rays, and the origin.
- Example 2, pp.74-75: vertical line x = k. Derive the real and imaginary parts,
  eliminate y for k nonzero, and identify the parabola and coordinate ranges.
  Include why k and -k give the same image, and the separate k = 0 case.
- Horizontal-line result following Example 2, p.75: derive equation (4) in full
  rather than saying 'similarly'; handle k nonzero, k and -k, and k = 0.
- Example 3, p.75: derive the image of EACH of the three sides of the triangle,
  including the two radial sides and the parabolic side. Retain all endpoints,
  side parameter/modulus bounds and final image description. Do not substitute
  one sketch or the final image for the three calculations.
- General power mapping, equation (5), pp.75-76: derive the modulus and argument
  transformation and the image of a ray for general integer n.
- Example 4, p.76: image of the circular wedge under the cubic mapping. Work
  through both radial and angular constraints, their transformed endpoints and
  inclusion of boundaries/origin. This example is mandatory and lies on p.76.

## Unit 9 - start of 2.4.2 through Example 5, pp.76-78

- Introductory root-function discussion and the two square roots in equation
  (6), p.77; explain why assigning both roots is not a single-valued function.
- Definition 2.4.1, equation (7), and the rewriting in equation (8): principal
  argument selection, k = 0, and the distinction from the set of square roots
  in Module I. Keep all angle/domain restrictions explicit.
- Example 5(a), (b), (c), pp.77-78: EVERY modulus, principal angle, substitution,
  root simplification, exponential/trigonometric evaluation, sign choice and
  final value. Part (c) continues onto the first lines of p.78; include it.
- Stop after Example 5(c). Do not add the following alternative-argument
  discussion or the inverse-function material later on p.78.

## Unit 10 - Principal nth Root Function and Example 9, p.82

- Begin BELOW the continuation of Example 8. Include the restricted argument
  sector in equation (12), the stated one-to-one/image reasoning and the exact
  domain and range of the principal nth-root function. Explain the local
  generalization in small steps from the formulas given on this page; do not
  import Examples 6-8 as extra lessons.
- Definition 2.4.3, equation (13); derive its equivalent polar/exponential form
  in equation (14), and explain the n = 2 special case and notation distinction.
- Example 9(a),(b): show ALL modulus and principal-argument calculations,
  substitution of n, angle division, root simplification and final evaluations,
  including the numerical approximation where the book gives one.
- Keep the principal nth-root FUNCTION distinct from the full set of n roots.
  Do not add p.83's multiple-valued functions or Riemann surfaces.
