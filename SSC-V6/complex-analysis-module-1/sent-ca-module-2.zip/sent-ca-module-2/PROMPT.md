# Complex Analysis I - Module II: Complex Functions, Mappings and Special Power Functions

Write the complete Module II study deck for Complex Analysis I (MAT5CJ303,
Calicut University, Semester V). The student is an undergraduate in India;
English is their second language. Use clear, short sentences without reducing
the mathematical detail. You are a content author, not an app developer.

**The user's special requirement: include ALL in-scope derivations, especially
every derivation and worked solution given in the textbook, and include ALL
steps. Do not select only representative derivations or compress away algebra.**

You work in AI chat with no filesystem or shell. Read the PDFs visually, including
overbars, roots, inequalities, diagrams and page boundaries. Reply in chat with
the JSON; the user will apply it to the existing shared Study Match engine.

## 1. Reading order and precedence

1. This `PROMPT.md`, then `OUTPUT-FORMAT.md`.
2. `source/syllabus.pdf`, especially its Module II table.
3. `source/map.md`, `source/DERIVATION-COVERAGE.md`, `source/SOURCE-NOTES.md`.
4. `skills/00-START-HERE.md` through `skills/08-definition-recall.md`.
5. `example/data-ca-m1.json`, the actual completed Complex Analysis Module I.
6. All five PDFs in `source/units/`, including each example's continuation page.

The syllabus and the precise stops below control scope. This prompt overrides
generic examples, approximate card counts, length suggestions, and physics or
model-paper instructions in the copied schema skills. The example JSON supplies
the schema and style, not an upper limit on detail, derivations or card counts.

## 2. Exact scope: five separate units, 6-10

Textbook: Dennis G. Zill and Patrick D. Shanahan, *Complex Analysis: A First
Course with Applications*, third edition. Use only the supplied sources.
Printed page numbers below are the book's footer numbers, not PDF-viewer numbers.

| Unit | Included content and exact stop | Source PDF | Printed pages |
|---|---|---|---|
| 6 | All of section 2.1, Complex Functions, including the continuation of Remarks on p.52; see the named-exercise exception below. | `unit-6-complex-functions.pdf` | 47-53 |
| 7 | Section 2.2 from its heading up to and including Example 4 and its complete solution. Stop before **Use of Computers** on p.59. | `unit-7-complex-functions-as-mappings.pdf` | 54-59 |
| 8 | Introduction to section 2.4 and ALL of 2.4.1, including Examples 1-4, both methods for Example 1, the horizontal-line discussion, and general power mappings. Stop before **2.4.2** on p.76. | `unit-8-power-function-z-n.pdf` | 72-76 |
| 9 | Section 2.4.2 from its heading on p.76 through Example 5(a), (b), (c). Part (c) ends at the top of p.78. Stop immediately after that solution. | `unit-9-principal-square-root-through-example-5.pdf` | 76-78 |
| 10 | On p.82 start at **Principal nth Root Function**; include the full discussion, equation (12), Definition 2.4.3, equations (13)-(14), and Example 9(a), (b) with complete solutions. | `unit-10-principal-nth-root-functions-and-example-9.pdf` | 82 |

**Overlap rules:** Unit 8's p.72 begins with an unrelated section 2.3 project:
ignore everything above the `2.4 Special Power Functions` heading. Its p.76 also
contains the start of Unit 9: Unit 8 must stop at the 2.4.2 heading. Conversely,
Unit 9 must ignore the Unit 8 material above that heading on p.76. On p.78 ignore
everything below Example 5(c), including the following alternative-argument
discussion and **Inverse Functions**. On p.82 ignore the continuation of Example
8 and Figure 2.4.14 above **Principal nth Root Function**.

**Do not write:** section 1.6 as a separate topic; section 2.3, linear/reciprocal
mapping theory and its project; section 2.2 **Use of Computers** or software code;
section 2.4 Examples 6, 7, 8 or their surrounding inverse-function lessons;
multiple-valued-function lessons, Riemann surfaces, rational/complex powers,
branches/cuts/points; sections 3 or 4 as later-module lessons. Mention inverse
functions only to the extent explicitly needed by the in-scope p.82 discussion.

Introductory complex exponentials and exponential notation in section 2.1 ARE
in scope. Do not delete them just because a later module studies exponentials
more deeply. However, do not import section 4.1 proofs that section 2.1 explicitly
defers. Clearly distinguish a stated property from a proof actually supplied.

Exercises are not extra topics. The exception is a problem explicitly named in
the included prose: section 2.1 names Problems 32 and 33. Print their statements
faithfully immediately after the sentence that names them, as in the PDF; do not
add the rest of Exercises 2.1. If supplying worked reasoning for those named
tasks, label it as a worked exercise based on the supplied statements and
formulas, not as a worked textbook solution. Never let these additions displace
any derivation or worked solution in the main text.

## 3. Exhaustive derivation coverage - mandatory

Before authoring, privately inventory EVERY derivation, worked example and
derived result within the allowed spans. Use `source/DERIVATION-COVERAGE.md` as
a minimum audit list, then inspect the PDFs for anything else. Do not assume
that only text labelled 'Derivation' counts. Algebra in explanatory paragraphs,
parametrizations, changes of variable, image boundaries, domain/range arguments,
special cases and alternative methods are also part of the required coverage.

- Include every in-scope numbered example with EVERY subpart and its complete
  working. Include unnumbered calculations and results derived in the prose.
- Use a separate `derivation` card per logically separate worked result or
  method. Split long cases into consecutively named derivation cards if needed;
  repeat the last established equation when the next card continues the proof.
- No hard maximum number of derivation cards or steps. In particular, the
  generic '4-12 steps' and '6-14 cards per sheet' suggestions are NOT limits.
  Completeness takes priority. Do not omit a derivation to satisfy a target count.
- Start from the problem's actual assumptions or defining equation. Do not start
  at the answer. End with the requested result and its valid domain/range or
  parameter interval, including boundary inclusion and exceptional cases.
- Preserve every printed intermediate equation, calculation, sign choice,
  parameter change, assumption and case split. Expand any printed chain of
  equalities into individual steps, and supply elementary intermediate algebra
  needed to connect the printed lines. Do not replace working with 'similarly',
  'clearly', 'after simplification', 'by substitution' or 'we get'.
- Explicitly show substitutions, distributive expansion, use of i squared,
  conjugation, collection of real/imaginary parts, elimination of parameters,
  interval transformations, modulus and argument calculations, quadrant choice,
  trigonometric evaluation, and numerical approximation wherever used.
- Keep every subcase. For instance, a formula obtained by division by k must
  handle k = 0 separately; a three-sided image needs all three side calculations.
  If the textbook gives two methods for one example, include both.
- Every `steps[].tex` is one line of bare TeX with ONE top-level relation.
  Use one mathematical move per step; split simultaneous results across steps.
  Keep side conditions in `note` when appropriate. The first step has no `move`;
  every later step uses an allowed move from `skills/02-derivations.md`.
  Use `evaluate` or `rearrange`, never an unsupported move such as `solve`.
- Every step has a short explanatory `note`. State the identity or reason that
  justifies the move. Use 3-6 meaningful phases and four decision checkpoints
  when there are four real decisions; for a very short calculation, use fewer
  checkpoints rather than inventing steps or asking redundant questions.
- An `ask` placed on a step asks about the immediately NEXT step; the final
  step has no next-step question. Answer indices are zero-based.
- Each derivation has a declarative JSXGraph `setup`, staged constructions and
  valid `focus` names. A mapping diagram must distinguish the z-plane and
  w-plane and show the relevant endpoints, angles, boundaries and orientation.
- Re-derive all working independently to catch sign, overbar and range mistakes.
  Check the visual PDF rather than trusting OCR. If you cannot resolve an
  apparent source error, disclose it in the final verification list; never
  silently copy a contradiction or invent a different textbook result.

## 4. Concepts, glossary and earlier material

Module I already covers complex-number arithmetic, conjugates, modulus,
distance, polar form, arguments, de Moivre's formula, nth roots as numbers,
neighborhoods, sets and domains. Its full JSON is the style/prerequisite
reference. Do not copy Module I cards or duplicate its glossary entries into
Module II. Briefly restate a needed prerequisite in the local explanation, but
create new glossary entries only for new Module II concepts or an explicit new
distinction (e.g. a principal root FUNCTION versus an individual root NUMBER).
Do not reference nonexistent Module I IDs from Module II `term` or `defines`.

Introduce each new concept with a plain-language `intuition` card immediately
before its technical `info` card. Define what the object IS before listing its
properties. Include an actual diagram, a short caption, a concrete source-based
example and a bridge to the formal statement. Use glossary entries for genuinely
unfamiliar in-scope terms. Every definition info card has `defines` and an `art`
JSXGraph figure for the shared engine's definition-recall flow.

End each unit with 3-5 concise `mcq`, `fill` or `number` quiz cards. These quizzes
supplement the derivations; they never replace the derivations or their steps.
Use only source-based facts and examples. Do not create model-paper rubrics,
score/Remember sequences, new UI, engine files, images to generate later, scripts
or runtime features. Author all educational content directly yourself.

## 5. JSON shape and engine settings

Return one object with keys `meta`, `match`, `glossary`, `sections`.

- `meta.title`: `Complex Analysis I — Module II: Complex Functions, Mappings and Special Power Functions`.
- `meta.subject`: `Complex Analysis I (MAT5CJ303, Sem 5)`.
- `meta.home`: `Focus`; `meta.opponent`: `Time`; `meta.version`: 1.
- `meta.inlineChecks`: false; `meta.autoRevealQuestions`: true;
  `meta.definitionChecks`: true; `meta.date`: `""`; `meta.sessions`: [].
- `match.periodEnds`: [25, 45, 70, 90]; `match.breaks`: [5, 10, 5].
- One section: id `ca-m2-section-1`, short/title `Module II`.
- Five sheets, in order: `ca-m2-unit-6`, `ca-m2-unit-7`, `ca-m2-unit-8`,
  `ca-m2-unit-9`, `ca-m2-unit-10`. Do not merge Units 9 and 10.
- Each sheet `source` begins with `Unit N · Zill & Shanahan §...` using its
  ACTUAL unit number. The shared engine uses that prefix for study-plan handoff.
  Example: `Unit 8 · Zill & Shanahan §2.4.1`.
- All new glossary/card IDs start `ca-m2-` and are unique. Preserve the separate
  Module I JSON; do not merge it into the returned file.
- Cite the printed equation/definition/example and section in labels or notes.
  Equation numbers restart by section, so do not cite an ambiguous bare number.
- TeX backslashes must be doubled inside JSON strings. Body text uses
  `\\( ... \\)`; `tex` and `move.by` contain bare TeX.

## 6. Final private audit and reply

Cross-check the JSON against every item in `source/DERIVATION-COVERAGE.md` and
every allowed PDF span. For each inventory item, privately identify the actual
card IDs and step sequence that cover it. Check every example subpart, prose
derivation, alternative method and boundary case. Correct any omissions BEFORE
replying. Then apply `skills/05-checklist.md` and `OUTPUT-FORMAT.md`.

Return the COMPLETE JSON, not a sample, outline, placeholder, shortened deck or
script to generate it. Do not truncate the JSON or remove working to fit a reply.
If a response limit truly prevents completion, disclose that instead of labelling
an incomplete deck complete. Do not write `none` in the final verification list
unless every included claim and all required coverage were actually checked.
