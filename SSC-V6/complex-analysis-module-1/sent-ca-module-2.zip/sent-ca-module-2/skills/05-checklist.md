# Final checklist - Complex Analysis Module II

## Scope and completeness
- Read the Module II syllabus, the exact inclusion/stopping points in PROMPT.md,
  all five unit PDFs, source/map.md and source/SOURCE-NOTES.md.
- Privately map EVERY item in source/DERIVATION-COVERAGE.md to the actual card
  IDs and steps. Then look for additional in-scope workings not on that list.
- Include all numbered examples, every subpart, unnumbered calculations,
  alternative methods, endpoint/range arguments and exceptional cases.
- Unit 8 includes Example 4 on p.76; Unit 9 includes Example 5(c) on p.78.
- Unit 10 begins at Principal nth Root Function on p.82, excludes Example 8,
  and includes both parts of Example 9.
- No prescribed maximum card/step count has caused omitted working.
- No placeholders, ellipses, generator scripts or incomplete JSON.

## Mathematics and provenance
- Re-derive each result, preserving the PDF's conjugations, radicals and signs.
- Check the actual visual pages. In 2.2 Example 3 the overbar covers iz.
- Keep the textbook's principal-argument convention and interval endpoints.
- Every required substitution, expansion, parameter elimination, trigonometric
  evaluation, angle choice and approximation is explicit.
- Do not claim a deferred proof or an exercise solution is printed working.
- Every source label and equation/example/definition reference is unambiguous.
- Disclose unverified claims, unresolved source issues and coverage gaps.

## JSON and engine
- Valid JSON: all backslashes doubled, no comments, trailing commas or NaN.
- Keys: meta, match, glossary, sections. Settings exactly as PROMPT.md.
- One Module II section and five sheets, ca-m2-unit-6 through ca-m2-unit-10.
- Each source starts Unit N, with the correct syllabus unit number.
- Unique ca-m2- IDs; no missing glossary references or copied Module I terms.
- Every new concept has a direct definition and an intuition introduction.
- Every definition info card has defines metadata and JSXGraph art.
- Every derivation has setup, phases, complete steps, notes and valid focus names.
- First step has no move; later steps each have one allowed move.
- A step's tex has one top-level relation, no aligned environment or inline
  math delimiters. Split chains across steps and show one move at a time.
- Needed move operands are present. No unsupported solve move.
- Each ask tests the NEXT step, with distinct options, a valid zero-based answer
  and teaching why; do not put next-step questions on the final step.
- Phase names are listed and actually used. Diagram construction steps correspond
  to the derivation and use only allowed object types and palette roles.
- Intuition art is SVG; technical art/setup use the declarative JSXGraph schema.
- Each unit ends with 3-5 source-based quizzes; all answer types and indices fit
  their schema, with short teaching explanations.
- Follow OUTPUT-FORMAT.md, not generic instructions to output bare JSON.
