# Start here - Complex Analysis Module II content authoring

Read the top-level PROMPT.md and OUTPUT-FORMAT.md first. The syllabus and exact
source boundaries there control this module. The remaining skills describe the
existing shared Study Match JSON schema and runtime; examples from other subjects
are structural examples, not topics to copy. Write only the new Module II JSON.

Author every educational statement, worked example, diagram, derivation step and
quiz directly yourself. Do not use scripts, loops, templates or generators to
populate educational content. No app code or runtime changes are requested.

The user requires ALL in-scope textbook derivations and worked solutions with
ALL steps. Audit every example, every subpart, all prose derivations, alternative
methods and exceptional cases against source/DERIVATION-COVERAGE.md and the PDFs.
Generic card-count and step-count suggestions are not limits. Do not shorten
working to meet them. Split a long result into clearly consecutive cards when
needed, keeping the full chain of reasoning intact.

Answer 'What is it?' in plain words before formal properties. Place an intuition
card with SVG art, picture caption, example and bridge before the technical
introduction of a new concept. Define unfamiliar in-scope terms in the glossary.
Follow 07-plain-words-and-glossary.md and 08-definition-recall.md. All layout,
animations, glossary popups, timers and definition-recall behavior already exist.

Use the actual completed Complex Analysis Module I JSON in example/ for shape
and style. Do not copy its subject matter, IDs or card-count choices into Module
II. The returned module must stand alone without dangling glossary references.

Use inlineChecks false, autoRevealQuestions true, definitionChecks true, empty
date and sessions. Use the sheet IDs and Unit N source prefixes in PROMPT.md.
Do not add model-paper questions, marking rubrics, score cards or Remember-card
sequences. Keep 3-5 topic quizzes per unit alongside the full derivation coverage.

Privately run 05-checklist.md before replying. Output exactly the complete fenced
JSON block followed by 'Not verified from the PDFs', as OUTPUT-FORMAT.md requires.
