# 06 — Match timing and study tools

These are app behaviours. Write content for them; do not reimplement them in JSON,
SVG, question text or model answers.

## Module II content

Author the source-based Complex Analysis Module II cards directly. The shared
engine already implements these tools. Do not write a new engine, change other
modules, or add model-paper questions, rubrics or Remember-card sequences.
Use inlineChecks false, autoRevealQuestions true and definitionChecks true.

## OMR arrival and scoring

With `autoRevealQuestions` enabled, `mcq`, `fill` and `number` cards reveal when
centred in an open topic. There is no tap-to-reveal control. Unvisited cards do
not start timers. Arrival does not force input focus or open the phone keyboard.
Timers pause off the current card, with the match centre open,
while the document is hidden, and during a break. Returning resumes the same
countdown; answering or timing out locks the card. Completed answers survive
reload without being scored again.

Three right answers in a row score for Focus; every third wrong answer or timeout
scores for Time. Remember OMR cards count toward quiz totals, topic completion
and coverage. Draft prose is self-marked with `eval` cards, not auto-graded.

## Custom match clock

In Match centre before kick-off, the student can enable **Custom halves**:

- Real duration of each half: a slider, 20–90 minutes, snapping every 5 minutes.
- Half-time break: a separate slider, 1–30 real minutes, snapping every minute.
- Two halves, ending at displayed match minutes 45 and 90; hydration can split
  each half into two study stretches.
- With real halves of at least 45 minutes, add hydration breaks at displayed match
  minutes 25 and 70. With shorter halves, omit hydration breaks. Use the exact
  name Hydration break, distinct from Half-time.
- Hydration duration is separately adjustable from 1–30 real minutes before kick-off.
- Match clock rate = 45 / chosen real minutes per half. At 20 real minutes,
  each half still displays 45 match minutes and the clock runs at 2.25x.
- Topic deadlines and added time use displayed match minutes.
- Half-time countdowns and question-answer timers use real time, without scaling.
- Settings are fixed during a running match and saved with that match. Reloading
  preserves its schedule and clock rate. A new/reset match uses saved preferences.
- Breaks use an on-screen alert. The student may choose Skip break at any time
  to resume the next stretch immediately, or wait for the countdown and explicitly
  resume afterward. Both hydration and half-time breaks are skippable. Question
  timers and derivations pause while the break is active.

Standard mode retains the one-to-one clock, with hydration breaks at 25 and 70.

## Focused start and pause

With meta.definitionChecks enabled, only match mode locks cards. Each sheet
unlocks independently in order; reading, quizzes and derivations retain their
own completion rules. Definition recall follows 08-definition-recall.md. Pause
and breaks disable its actions; self-confirmations and skips do not score shots.

The notch layout is the default from initial load, including before kick-off.
Its control button reveals the full header; its Match centre button is always
accessible. During play, Pause match freezes the match clock, quiz countdowns
and derivation playback. Resume shifts the time origin so paused time never
counts. Paused state survives reload. Match centre also offers Pause/Resume.
An optional content default is:

```json
"match": {
  "periodEnds": [25, 45, 70, 90],
  "breaks": [5, 10, 5],
  "timing": { "mode": "custom", "halfMinutes": 30, "halfTimeMinutes": 10 }
}
```

The runtime handles the two-half schedule and optional hydration in custom mode; do not rewrite
`periodEnds`, deadlines, or question times to imitate an accelerated clock.

## Maths and calculator

Inline tags support MathJax `\\( ... \\)`; prefer explicit delimiters to bare
notation. The bundled scientific calculator opens with `=` or the toolbar button,
uses RAD/DEG modes, and has `?` help. Numerical answer boxes can open it with `=`
and receive a real scalar result through **Use answer**. Do not add a custom
calculator or instructional controls to authored card content.

## Scope

These runtime descriptions explain the JSON metadata and card behavior. Only
Module II educational JSON is requested. The exact source spans, required
coverage and response format are in the top-level PROMPT.md.
