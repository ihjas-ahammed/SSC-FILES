# Files in this upload (round 3)

All files are at the top level. Use the "Path in app" column in diff headers
(for example `--- a/study-match/src/components/03-render.js`).

| Uploaded file | Path in app |
|---|---|
| prompt.md | (this prompt) |
| 00-START-HERE.md | skills/00-START-HERE.md |
| 01-schema.md | skills/01-schema.md |
| 02-derivations.md | skills/02-derivations.md |
| 03-svg-art.md | skills/03-svg-art.md |
| 04-questions.md | skills/04-questions.md |
| 05-checklist.md | skills/05-checklist.md |
| 06-match-and-tools.md | skills/06-match-and-tools.md |
| 07-plain-words-and-glossary.md | skills/07-plain-words-and-glossary.md |
| 08-definition-recall.md | skills/08-definition-recall.md |
| example-minimal.json | skills/example-minimal.json |
| data.json | study-match/data/data.json (FULL FILE, not a diff) |
| 02-mathflow.js | study-match/src/components/02-mathflow.js |
| 03-render.js | study-match/src/components/03-render.js |
| 04-shelf.js | study-match/src/components/04-shelf.js |
| 01-tokens.css | study-match/src/styles/01-tokens.css |
| 05-cards.css | study-match/src/styles/05-cards.css |
| 07-mathflow.css | study-match/src/styles/07-mathflow.css |
| 09-desktop.css | study-match/src/styles/09-desktop.css |
| 10-practice.css | study-match/src/styles/10-practice.css |
| syllabus.pdf | source/syllabus.pdf |
| unit-1-fermat-laws-reflection-refraction.pdf | source/units/unit-1-fermat-laws-reflection-refraction.pdf |
| unit-2-refraction-reflection-single-spherical-surface.pdf | source/units/unit-2-refraction-reflection-single-spherical-surface.pdf |
| unit-3-thin-lens-principal-foci-focal-length.pdf | source/units/unit-3-thin-lens-principal-foci-focal-length.pdf |
| unit-4-newton-formula-lateral-magnification.pdf | source/units/unit-4-newton-formula-lateral-magnification.pdf |
| map.md | source/map.md |
| tda.html | doc/tda.html |
| TDA-briefing-2026-10-23.md | doc/TDA-briefing-2026-10-23.md |
