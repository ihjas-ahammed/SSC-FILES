# Optics Module 1 — Round 3 changes

You are improving the Study Match app and its Optics Module 1 deck.
The student is in high school in India. English is their second language.
Use short sentences and simple words. Explain any hard word in one plain sentence.

All files are at the top level of this upload. `FILES.md` gives each file's
path in the app. Use those paths in diff headers.

## What you return

1. **data.json**: the FULL file (valid JSON), `study-match/data/data.json`.
   It is too big for a diff, so return it whole.
2. **A diff for everything else**: one unified diff in one block, covering the
   app code, the CSS and the skill files. Paths are the paths in `FILES.md`,
   for example `--- a/study-match/src/components/03-render.js` and
   `+++ b/study-match/src/components/03-render.js`.
   I apply it with `patch -p1` from the `optics-module-1` folder.
3. **Short notes** in plain English: what changed, and anything you could not do.

Diff rules (these matter, because earlier diffs had errors):
- Copy every context line exactly from the file you were given. Do not retype
  lines from memory.
- Recount the numbers in every `@@ -a,b +c,d @@` header from the hunk body.
- Keep the same tabs and spaces as the original.
- Do not reformat code you are not changing.
- Do not add packages or network calls. Do not write study content with scripts.

## Change 1: show the line when it is mentioned

When a derivation step, a card's text or a picture label refers to a line
(a ray, a path, a side of a triangle, an arc), that line must be highlighted in the
picture at the same time. Use the existing highlight class (`mf-part-on` or the
amber classes in `03-svg-art.md`). Each picture's labels must match the names used in the steps.

- Give each highlightable part of an SVG a `data-part="name"` attribute.
- Each derivation step and each `note` can name the parts it uses, with a `focus`
  field (for example `"focus": ["ray1", "normal"]`). The app highlights those parts.
- Document this in `01-schema.md` and `03-svg-art.md`.

## Change 2: use the app's colour palette only

The derivation colours are hard-coded in `07-mathflow.css` (`#b45309`, `#be123c`,
`#0369a1` and the dark-mode values). Some of them look like red or rose and do not
match the rest of the app.

- Remove all hard-coded colours from `07-mathflow.css` and from the math animation
  in `02-mathflow.js` (for example `--mf-cancel` and `--mf-result` are wrong).
- Use only the tokens from `01-tokens.css`: `--ink`, `--ink-2`, `--muted`, `--violet`,
  `--amber`, `--hl`, `--sage`, `--lav`, `--lav-2`, and their dark-mode values.
- Cancelled terms: use `--muted` with a strike line. Do not use red or rose.
- Active step: `--hl` (amber). Final result: `--violet`. Given terms: `--ink`.
- Correct tick: `--sage`. Wrong answer: `--coral` only in the quiz feedback, not in maths.

## Change 3: detailed derivation steps, and parallel steps one after another

- Write the derivation in full detail: every algebra move, every approximation, and
  every sign decision. Do not skip a step that a student in Year 2 would need.
- When two things happen in parallel (for example the two surfaces of a thin lens,
  or the refraction at surface 1 and at surface 2), show them one after the other as
  separate steps, each with its own phase label. Do not show them side by side.
- Each step still has one move (see `02-derivations.md`).

## Change 4: desktop layout and a summary of each derivation

Desktop and wide screens (above 900 px wide, in `09-desktop.css`):

- A wide card for a derivation: the picture (`setup`) on the **left**, and the
  equations, the step note and the question area on the **right**. The student
  can see the picture and the equation at the same time.
- Give the wide card a summary view: a stage that lists **all** steps of the
  derivation in order (one line each: step number, the equation, and the move).
  Show it after the last step, and open it from a button at any time.
- On a phone the layout stays as it is (picture on top, equations below).
- Check the sizes against 720 × 1520 for phones and about 1440 × 900 for desktop.

## Change 5: be consistent with the textbook

- Use the same symbols, signs and names as the textbook (Ghatak, *Optics*):
  the Cartesian sign convention, the same symbols for object and image distances,
  focal lengths and refractive indices.
- Check each derivation against the unit PDF it comes from (`unit-1` to `unit-4`).
  Use the same section names.
- If the textbook and this deck differ, the textbook wins. Say so in your notes.
- Keep `source` fields on every sheet, with the section number.

## Change 6: update the skills from what we learned

Update these skill files so that the rules match the code after your changes:
- `01-schema.md`: the `focus` field, `data-part`, the summary view, the parallel-step rule.
- `02-derivations.md`: detailed steps, parallel steps one after another, the
  summary, and the rule for naming the line in each step.
- `03-svg-art.md`: `data-part` on highlightable parts, arcs, and the palette classes only.
- `04-questions.md`: keep the short-question rules, and check them against the new derivation.
- `05-checklist.md`: add a check for the textbook match, the palette and the highlight rule.

Keep every other skill file as it is, unless a rule in it conflicts with the code.

## Keep these working

Auto-reveal quizzes, the timers, the calculator, custom halves, breaks with Skip,
Pause/Resume, the locked cards during a match, the flip cards, the saved progress.
Card IDs for existing cards must stay the same.

## Check before you return

- `data.json` is valid JSON, and every derivation step that uses a line names it in `focus`.
- Every changed JavaScript file has no syntax errors.
- No red, rose or other colour outside the palette tokens remains in the maths code.
- Each diff hunk header matches its body.
