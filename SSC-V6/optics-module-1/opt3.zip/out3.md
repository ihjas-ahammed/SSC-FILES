### 1. `study-match/data/data.json`

```json
{
  "meta": {
    "title": "Optics Module 1 — Geometrical Optics",
    "subject": "Physics (PHY5B08 · CU-FYUGP Semester V)",
    "home": "Focus",
    "opponent": "Time",
    "version": 1,
    "date": "",
    "sessions": [],
    "inlineChecks": false,
    "autoRevealQuestions": true,
    "definitionChecks": true
  },
  "match": {
    "periodEnds": [25, 45, 70, 90],
    "breaks": [5, 10, 5],
    "timing": {
      "mode": "custom",
      "halfMinutes": 30,
      "halfTimeMinutes": 10,
      "hydrationMinutes": 5
    }
  },
  "glossary": [
    {
      "id": "ray",
      "term": "ray",
      "aliases": ["rays", "light ray", "light rays"],
      "definition": "A ray is an infinitely thin line showing the path along which light energy travels when wavelength goes to zero.",
      "example": "A narrow laser beam in air travels along a straight ray."
    },
    {
      "id": "geometrical-optics",
      "term": "geometrical optics",
      "aliases": ["ray optics"],
      "definition": "Geometrical optics is the study of light propagation using rays by neglecting the tiny finite wavelength of light.",
      "example": "Tracing rays through eyeglasses or a camera lens uses geometrical optics."
    },
    {
      "id": "diffraction",
      "term": "diffraction",
      "definition": "Diffraction is the spreading of light at the edges of a very small opening because light has a finite wavelength.",
      "example": "A hole smaller than 0.1 mm blurs the sharp shadow on a screen."
    },
    {
      "id": "refractive-index",
      "term": "refractive index",
      "aliases": ["index of refraction"],
      "definition": "The refractive index n of a medium is the ratio of the speed of light in vacuum c to its speed v in that medium.",
      "example": "Glass with n = 1.5 slows light to c / 1.5."
    },
    {
      "id": "homogeneous-medium",
      "term": "homogeneous medium",
      "aliases": ["homogeneous"],
      "definition": "A homogeneous medium is a material whose refractive index has the same constant value at every point.",
      "example": "Calm air at uniform temperature is a homogeneous medium."
    },
    {
      "id": "optical-path-length",
      "term": "optical path length",
      "aliases": ["optical path"],
      "definition": "Optical path length is the geometric distance light travels multiplied by the refractive index of the medium.",
      "example": "Travelling 2 cm in glass of n = 1.5 gives an optical path length of 3 cm."
    },
    {
      "id": "stationary-path",
      "term": "stationary path",
      "aliases": ["extremum", "stationary"],
      "definition": "A stationary path is a path whose travel time does not change to first order when the path is slightly shifted.",
      "example": "At the bottom of a smooth valley, a tiny step sideways does not change height."
    },
    {
      "id": "fermats-principle",
      "term": "Fermat's principle",
      "aliases": ["principle of least time"],
      "definition": "Fermat's principle states that a light ray between two points follows a path whose optical path length is stationary.",
      "example": "Light bends at water so the total travel time stays stationary."
    },
    {
      "id": "refraction",
      "term": "refraction",
      "aliases": ["refracted", "Snell's law"],
      "definition": "Refraction is the bending of a light ray when it crosses the boundary between two media of different refractive indices.",
      "example": "A spoon in a glass of water looks bent at the water surface."
    },
    {
      "id": "paraxial-approximation",
      "term": "paraxial approximation",
      "aliases": ["paraxial", "paraxial rays"],
      "definition": "The paraxial approximation restricts rays to small angles with the optical axis so sin θ and tan θ equal θ in radians.",
      "example": "For an angle of 0.05 rad, sin 0.05 is very close to 0.05."
    },
    {
      "id": "center-of-curvature",
      "term": "center of curvature",
      "aliases": ["centers of curvature", "radius of curvature"],
      "definition": "The center of curvature C is the center of the sphere of which a curved mirror or lens surface forms a part.",
      "example": "A normal line drawn at any point on a spherical surface passes through C."
    },
    {
      "id": "meridional-ray",
      "term": "meridional ray",
      "aliases": ["meridional rays", "skew rays"],
      "definition": "A meridional ray is a ray that stays inside a single flat plane containing the optical axis.",
      "example": "Any ray starting from a point on the optical axis is a meridional ray."
    },
    {
      "id": "thin-lens",
      "term": "thin lens",
      "aliases": ["thin spherical lens", "spherical lens"],
      "definition": "A thin lens is a lens whose thickness is very small compared to the object distance, image distance, and surface radii.",
      "example": "A thin spectacle lens allows all distances to be measured from its center P."
    },
    {
      "id": "principal-focus",
      "term": "principal focus",
      "aliases": ["first principal focus", "second principal focus", "principal foci", "focal length"],
      "definition": "A principal focus is an axial point paired with rays parallel to the axis either after or before passing through the lens.",
      "example": "Sunlight parallel to the axis meets at the second principal focus F₂."
    },
    {
      "id": "lateral-magnification",
      "term": "lateral magnification",
      "aliases": ["magnification"],
      "definition": "Lateral magnification m is the ratio of the transverse image height y' to the transverse object height y.",
      "example": "If a 1 cm object forms an inverted 2 cm image, the lateral magnification is -2."
    }
  ],
  "sections": [
    {
      "short": "Fermat",
      "title": "Fermat's Principle & Spherical Surfaces",
      "sheets": [
        {
          "id": "fermat-laws-reflection-refraction",
          "title": "Fermat's principle & laws",
          "icon": "wave",
          "source": "Unit 1 · Ghatak §§3.1–3.2 (PDF pp. 56–61)",
          "cards": [
            {
              "type": "intuition",
              "term": "geometrical-optics",
              "title": "When light behaves like thin straight pencils",
              "meaning": "Geometrical optics is the model of light as thin directional lines called rays when openings are much larger than the wavelength.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Point source P shining through a wide aperture onto screen SS prime\"><line x1=\"115\" y1=\"16\" x2=\"115\" y2=\"58\" class=\"lk\" stroke-width=\"3\" data-part=\"AB\"/><line x1=\"115\" y1=\"122\" x2=\"115\" y2=\"164\" class=\"lk\" stroke-width=\"3\" data-part=\"AB\"/><line x1=\"215\" y1=\"16\" x2=\"215\" y2=\"164\" class=\"lk\" stroke-width=\"2\" data-part=\"SS\"/><polygon points=\"32,90 215,34 215,146\" class=\"s\" data-part=\"cone\"/><line x1=\"32\" y1=\"90\" x2=\"215\" y2=\"34\" class=\"lk\" stroke-width=\"1.8\" data-part=\"cone\"/><line x1=\"32\" y1=\"90\" x2=\"215\" y2=\"146\" class=\"lk\" stroke-width=\"1.8\" data-part=\"cone\"/><line x1=\"32\" y1=\"90\" x2=\"215\" y2=\"90\" class=\"hk\" stroke-width=\"2.5\" data-part=\"ray\"/><path d=\"M 62 81 A 32 32 0 0 1 62 99\" class=\"lk\" stroke-width=\"1.8\" data-part=\"angle\"/><circle cx=\"32\" cy=\"90\" r=\"4\" class=\"h\" data-part=\"P\"/><text x=\"20\" y=\"94\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"115\" y=\"12\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"AB\">A</text><text x=\"115\" y=\"175\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"AB\">B</text><text x=\"162\" y=\"84\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"ray\">Ray (λ→0)</text><text x=\"228\" y=\"28\" font-size=\"11\" class=\"t\" data-part=\"SS\">S</text><text x=\"228\" y=\"160\" font-size=\"11\" class=\"t\" data-part=\"SS\">S'</text></svg>",
              "picture": "Look at the sharp cone of rays from P through wide opening AB onto screen SS'.",
              "example": "Visible light has a tiny wavelength near 0.0005 cm, so ordinary lenses and mirrors are huge compared to it.",
              "bridge": "In the mathematical limit where wavelength λ goes to zero, diffraction disappears and light energy follows thin paths called rays."
            },
            {
              "type": "info",
              "label": "01 · §3.1 Definition",
              "title": "What is geometrical optics?",
              "defines": ["geometrical-optics", "ray", "diffraction"],
              "body": "Geometrical optics treats light propagation using thin rays by neglecting the finite wavelength of light when apertures are large.",
              "tex": "\\lambda \\to 0",
              "examples": [
                "Hole ~ 1 cm: sharp",
                "Hole < 0.1 mm: blurs",
                "λ ~ 10⁻⁵ cm"
              ]
            },
            {
              "type": "intuition",
              "term": "optical-path-length",
              "title": "Why denser media count as longer paths",
              "meaning": "Optical path length is the vacuum distance that light would travel in the same time it takes to cross a medium.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Physical thickness d in glass compared with longer optical path n times d in vacuum\"><rect x=\"65\" y=\"24\" width=\"80\" height=\"52\" rx=\"6\" class=\"s ok\" data-part=\"glass\"/><line x1=\"24\" y1=\"50\" x2=\"185\" y2=\"50\" class=\"lk\" stroke-width=\"2.2\" data-part=\"d\"/><line x1=\"65\" y1=\"130\" x2=\"185\" y2=\"130\" class=\"hk\" stroke-width=\"3\" data-part=\"Lop\"/><circle cx=\"65\" cy=\"130\" r=\"4\" class=\"h\" data-part=\"Lop\"/><circle cx=\"185\" cy=\"130\" r=\"3.5\" class=\"f\" data-part=\"Lop\"/><line x1=\"65\" y1=\"84\" x2=\"65\" y2=\"142\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"guide\"/><line x1=\"145\" y1=\"84\" x2=\"145\" y2=\"112\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"guide\"/><text x=\"105\" y=\"44\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"glass\">Glass (n = 1.5)</text><text x=\"105\" y=\"68\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"d\">d = 2 cm</text><text x=\"125\" y=\"120\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"Lop\">L_op = n d = 3 cm</text><text x=\"125\" y=\"152\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"Lop\">Same travel time τ in vacuum</text></svg>",
              "picture": "Compare the 2 cm glass block (top) with the 3 cm vacuum path (bottom) that takes the exact same time.",
              "example": "In glass with refractive index n = 1.5, a physical thickness of 2 cm has an optical path length of 1.5 × 2 cm = 3 cm.",
              "bridge": "Because speed in a medium is c / n, the time for step ds is (n ds) / c, so integrating n ds gives the optical path length."
            },
            {
              "type": "info",
              "label": "02 · §3.1 Definition",
              "title": "What is optical path length?",
              "defines": ["optical-path-length", "refractive-index"],
              "body": "Optical path length is the integral of refractive index n along the geometric path, equal to c times the travel time.",
              "tex": "\\tau = \\frac{1}{c}\\int_{A}^{B} n\\,ds",
              "examples": [
                "dt = n ds / c",
                "L_op = ∫ n ds"
              ]
            },
            {
              "type": "intuition",
              "term": "fermats-principle",
              "title": "How light chooses its path",
              "meaning": "Fermat's principle says light travels along a path whose travel time is stationary compared with slightly different nearby paths.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Actual stationary ray path ACB compared with nearby dashed trial paths\"><path d=\"M 30 138 Q 115 32 230 42\" class=\"gk\" stroke-dasharray=\"5 4\" stroke-width=\"1.8\" data-part=\"ACprimeB\"/><path d=\"M 30 138 Q 130 92 230 42\" class=\"hk\" stroke-width=\"2.8\" data-part=\"ACB\"/><path d=\"M 30 138 Q 148 148 230 42\" class=\"gk\" stroke-dasharray=\"5 4\" stroke-width=\"1.8\" data-part=\"ADB\"/><path d=\"M 56 116 A 34 34 0 0 1 64 134\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ACB\"/><circle cx=\"30\" cy=\"138\" r=\"4\" class=\"h\" data-part=\"A\"/><circle cx=\"230\" cy=\"42\" r=\"4\" class=\"f\" data-part=\"B\"/><text x=\"18\" y=\"148\" font-size=\"12\" class=\"t\" data-part=\"A\">A</text><text x=\"238\" y=\"40\" font-size=\"12\" class=\"t\" data-part=\"B\">B</text><text x=\"112\" y=\"52\" font-size=\"11\" class=\"t\" data-part=\"ACprimeB\">Trial path C'</text><text x=\"128\" y=\"88\" font-size=\"12\" class=\"t\" data-part=\"ACB\">Actual ray C</text><text x=\"162\" y=\"138\" font-size=\"11\" class=\"t\" data-part=\"ACB\">δ ∫ n ds = 0</text></svg>",
              "picture": "Look at the solid amber ray ACB between the two dashed trial paths where small shifts do not change travel time.",
              "example": "In uniform air, the straight line between A and B has the shortest optical path. Inside an elliptical mirror, every path from focus S₁ to focus S₂ has the exact same length.",
              "bridge": "Therefore the modern statement replaces 'least time' with 'stationary optical path length': δ ∫ n ds = 0, allowing a minimum, maximum, or constant value."
            },
            {
              "type": "info",
              "label": "03 · §3.1 Definition",
              "title": "What is Fermat's principle?",
              "defines": ["fermats-principle", "stationary-path", "homogeneous-medium"],
              "body": "Fermat's principle states that the actual ray path between two points makes the optical path length stationary with respect to small path variations.",
              "tex": "\\delta \\int_{A}^{B} n\\,ds = 0",
              "examples": [
                "Minimum time",
                "Maximum time",
                "Stationary time"
              ]
            },
            {
              "type": "info",
              "label": "04 · §3.2 Reflection",
              "title": "Laws of reflection from Fermat's principle",
              "body": "Reflecting A across mirror MN to A' makes AP + PB = A'P + PB. A straight line A'PB minimizes length, so angle i equals angle r in one plane.",
              "examples": [
                "AP = PA'",
                "∠APS = ∠SPB",
                "i = r"
              ],
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Reflection at plane mirror MN using image point A prime\"><line x1=\"20\" y1=\"115\" x2=\"240\" y2=\"115\" class=\"lk\" stroke-width=\"2.5\" data-part=\"MN\"/><line x1=\"60\" y1=\"40\" x2=\"60\" y2=\"165\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"ARAprime\"/><line x1=\"135\" y1=\"35\" x2=\"135\" y2=\"115\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"PS\"/><line x1=\"60\" y1=\"165\" x2=\"135\" y2=\"115\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"AprimeP\"/><polyline points=\"60,40 135,115 215,35\" class=\"hk\" stroke-width=\"2.5\" data-part=\"APB\"/><path d=\"M 118 98 A 24 24 0 0 1 135 91\" class=\"lk\" stroke-width=\"1.8\" data-part=\"i\"/><path d=\"M 135 91 A 24 24 0 0 1 152 98\" class=\"lk\" stroke-width=\"1.8\" data-part=\"r\"/><circle cx=\"60\" cy=\"40\" r=\"3.5\" class=\"f\" data-part=\"A\"/><circle cx=\"60\" cy=\"165\" r=\"3.5\" class=\"f\" data-part=\"Aprime\"/><circle cx=\"135\" cy=\"115\" r=\"4\" class=\"h\" data-part=\"P\"/><circle cx=\"215\" cy=\"35\" r=\"3.5\" class=\"f\" data-part=\"B\"/><text x=\"46\" y=\"42\" font-size=\"12\" class=\"t\" data-part=\"A\">A</text><text x=\"42\" y=\"168\" font-size=\"12\" class=\"t\" data-part=\"Aprime\">A'</text><text x=\"68\" y=\"110\" font-size=\"11\" class=\"t\" data-part=\"R\">R</text><text x=\"135\" y=\"132\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"135\" y=\"28\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"PS\">S</text><text x=\"224\" y=\"38\" font-size=\"12\" class=\"t\" data-part=\"B\">B</text><text x=\"118\" y=\"78\" font-size=\"12\" class=\"t\" data-part=\"i\">i</text><text x=\"152\" y=\"78\" font-size=\"12\" class=\"t\" data-part=\"r\">r</text><text x=\"232\" y=\"132\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"MN\">M → N</text></svg>"
            },
            {
              "type": "derivation",
              "label": "05 · §3.2 Derivation",
              "title": "Laws of refraction from Fermat's principle",
              "legend": "Interface \\(PQ\\) separates media \\(n_1, n_2\\) with perpendiculars \\(AM = h_1\\), \\(BN = h_2\\), \\(MR = x\\), and \\(RN = L - x\\) (Fig. 3.5).",
              "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Refraction geometry between media n1 and n2\"><line x1=\"18\" y1=\"92\" x2=\"242\" y2=\"92\" class=\"lk\" stroke-width=\"2\" data-part=\"PQ\"/><line x1=\"52\" y1=\"26\" x2=\"52\" y2=\"92\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"AM\"/><line x1=\"52\" y1=\"92\" x2=\"128\" y2=\"92\" class=\"lk\" stroke-width=\"2.2\" data-part=\"MR\"/><line x1=\"128\" y1=\"92\" x2=\"208\" y2=\"92\" class=\"lk\" stroke-width=\"2.2\" data-part=\"RN\"/><line x1=\"208\" y1=\"92\" x2=\"208\" y2=\"158\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"BN\"/><line x1=\"128\" y1=\"22\" x2=\"128\" y2=\"162\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"normal\"/><line x1=\"52\" y1=\"26\" x2=\"128\" y2=\"92\" class=\"hk\" stroke-width=\"2.5\" data-part=\"AR\"/><line x1=\"128\" y1=\"92\" x2=\"208\" y2=\"158\" class=\"lk\" stroke-width=\"2.5\" data-part=\"RB\"/><path d=\"M 52 50 A 24 24 0 0 0 70 42\" class=\"lk\" stroke-width=\"1.8\" data-part=\"theta1\"/><path d=\"M 108 75 A 26 26 0 0 1 128 66\" class=\"lk\" stroke-width=\"1.8\" data-part=\"theta1\"/><path d=\"M 128 118 A 26 26 0 0 0 148 109\" class=\"lk\" stroke-width=\"1.8\" data-part=\"theta2\"/><circle cx=\"52\" cy=\"26\" r=\"3.5\" class=\"f\" data-part=\"A\"/><circle cx=\"128\" cy=\"92\" r=\"4\" class=\"h\" data-part=\"R\"/><circle cx=\"208\" cy=\"158\" r=\"3.5\" class=\"f\" data-part=\"B\"/><text x=\"38\" y=\"28\" font-size=\"12\" class=\"t\" data-part=\"A\">A</text><text x=\"34\" y=\"64\" font-size=\"11\" class=\"t\" data-part=\"AM\">h₁</text><text x=\"52\" y=\"106\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"MR\">M</text><text x=\"90\" y=\"86\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"MR\">x</text><text x=\"115\" y=\"56\" font-size=\"11\" class=\"t\" data-part=\"theta1\">θ₁</text><text x=\"138\" y=\"85\" font-size=\"11\" class=\"t\" data-part=\"R\">R</text><text x=\"142\" y=\"132\" font-size=\"11\" class=\"t\" data-part=\"theta2\">θ₂</text><text x=\"168\" y=\"106\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"RN\">L-x</text><text x=\"208\" y=\"86\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"RN\">N</text><text x=\"222\" y=\"130\" font-size=\"11\" class=\"t\" data-part=\"BN\">h₂</text><text x=\"220\" y=\"162\" font-size=\"12\" class=\"t\" data-part=\"B\">B</text><text x=\"225\" y=\"42\" font-size=\"12\" class=\"t\" data-part=\"AR\">n₁</text><text x=\"225\" y=\"112\" font-size=\"12\" class=\"t\" data-part=\"RB\">n₂</text></svg>",
              "phases": [
                {
                  "name": "Optical path",
                  "why": "sum optical paths n₁ AR and n₂ RB"
                },
                {
                  "name": "First medium",
                  "why": "write AR from right triangle AMR"
                },
                {
                  "name": "Second medium",
                  "why": "write RB from right triangle RBN"
                },
                {
                  "name": "Stationary path",
                  "why": "differentiate L_op with respect to x and set to zero"
                },
                {
                  "name": "Incidence angle",
                  "why": "substitute sin θ₁ in medium n₁"
                },
                {
                  "name": "Refraction angle",
                  "why": "substitute sin θ₂ in medium n₂ to reach Snell's law"
                }
              ],
              "steps": [
                {
                  "phase": "Optical path",
                  "focus": ["AR", "RB", "R"],
                  "tex": "L_{op} = n_1 AR + n_2 RB",
                  "note": "Write total optical path length from \\(A\\) to \\(B\\) via point \\(R\\) on \\(PQ\\)."
                },
                {
                  "phase": "First medium",
                  "focus": ["AR", "AM", "MR"],
                  "move": {
                    "type": "substitute",
                    "by": "AR = \\sqrt{x^2 + h_1^2}"
                  },
                  "tex": "L_{op} = n_1\\sqrt{x^2 + h_1^2} + n_2 RB",
                  "note": "In right triangle \\(AMR\\), replace \\(AR\\) with \\(\\sqrt{x^2 + h_1^2}\\)."
                },
                {
                  "phase": "Second medium",
                  "focus": ["RB", "BN", "RN"],
                  "move": {
                    "type": "substitute",
                    "by": "RB = \\sqrt{(L - x)^2 + h_2^2}"
                  },
                  "tex": "L_{op} = n_1\\sqrt{x^2 + h_1^2} + n_2\\sqrt{(L - x)^2 + h_2^2}",
                  "note": "In right triangle \\(RBN\\), replace \\(RB\\) with \\(\\sqrt{(L - x)^2 + h_2^2}\\) (Eq. 3.4)."
                },
                {
                  "phase": "Stationary path",
                  "focus": ["R", "MR", "RN"],
                  "move": {
                    "type": "differentiate",
                    "wrt": "x"
                  },
                  "tex": "\\frac{dL_{op}}{dx} = \\frac{n_1 x}{\\sqrt{x^2 + h_1^2}} - \\frac{n_2(L - x)}{\\sqrt{(L - x)^2 + h_2^2}}",
                  "note": "Differentiate \\(L_{op}\\) with respect to \\(x\\); the chain rule on \\((L - x)^2\\) gives a minus sign.",
                  "ask": {
                    "q": "How do we find the stationary ray path as \\(x\\) varies?",
                    "options": [
                      "Differentiate \\(L_{op}\\) with respect to \\(x\\)",
                      "Integrate \\(L_{op}\\) over \\(h_1\\)",
                      "Multiply both sides by \\(L\\)",
                      "Set \\(n_1 = n_2\\)"
                    ],
                    "answer": 0,
                    "why": "Fermat's principle requires differentiating the optical path with respect to \\(x\\)."
                  }
                },
                {
                  "focus": ["R", "AR", "RB"],
                  "move": {
                    "type": "evaluate",
                    "by": "\\frac{dL_{op}}{dx} = 0"
                  },
                  "tex": "0 = \\frac{n_1 x}{\\sqrt{x^2 + h_1^2}} - \\frac{n_2(L - x)}{\\sqrt{(L - x)^2 + h_2^2}}",
                  "note": "Set \\(dL_{op}/dx = 0\\) for an extremum optical path (Eq. 3.5).",
                  "ask": {
                    "q": "What value must \\(dL_{op}/dx\\) take on the actual ray path?",
                    "options": [
                      "\\(dL_{op}/dx = 0\\)",
                      "\\(dL_{op}/dx = 1\\)",
                      "\\(dL_{op}/dx = c\\)",
                      "\\(dL_{op}/dx = n_1\\)"
                    ],
                    "answer": 0,
                    "why": "At a stationary point of the optical path, the first derivative vanishes."
                  }
                },
                {
                  "phase": "Incidence angle",
                  "focus": ["theta1", "AR", "MR"],
                  "move": {
                    "type": "substitute",
                    "by": "\\sin\\theta_1 = \\frac{x}{\\sqrt{x^2 + h_1^2}}"
                  },
                  "tex": "0 = n_1\\sin\\theta_1 - \\frac{n_2(L - x)}{\\sqrt{(L - x)^2 + h_2^2}}",
                  "note": "In right triangle \\(AMR\\), substitute \\(\\sin\\theta_1 = x/\\sqrt{x^2 + h_1^2}\\).",
                  "ask": {
                    "q": "What does \\(x / \\sqrt{x^2 + h_1^2}\\) equal in triangle \\(AMR\\)?",
                    "options": [
                      "\\(\\sin\\theta_1\\)",
                      "\\(\\cos\\theta_1\\)",
                      "\\(\\tan\\theta_1\\)",
                      "\\(1 / \\sin\\theta_1\\)"
                    ],
                    "answer": 0,
                    "why": "Side \\(MR = x\\) is opposite \\(\\theta_1\\) and \\(AR = \\sqrt{x^2 + h_1^2}\\) is the hypotenuse."
                  }
                },
                {
                  "phase": "Refraction angle",
                  "focus": ["theta2", "RB", "RN"],
                  "move": {
                    "type": "substitute",
                    "by": "\\sin\\theta_2 = \\frac{L - x}{\\sqrt{(L - x)^2 + h_2^2}}"
                  },
                  "tex": "0 = n_1\\sin\\theta_1 - n_2\\sin\\theta_2",
                  "note": "In right triangle \\(RBN\\), substitute \\(\\sin\\theta_2 = (L - x)/\\sqrt{(L - x)^2 + h_2^2}\\)."
                },
                {
                  "focus": ["theta1", "theta2", "normal"],
                  "move": {
                    "type": "add",
                    "by": "n_2\\sin\\theta_2"
                  },
                  "tex": "n_2\\sin\\theta_2 = n_1\\sin\\theta_1",
                  "note": "Add \\(n_2\\sin\\theta_2\\) to both sides.",
                  "ask": {
                    "q": "Which move places the two refraction terms on opposite sides?",
                    "options": [
                      "Add \\(n_2\\sin\\theta_2\\) to both sides",
                      "Divide by \\(\\cos\\theta_1\\)",
                      "Subtract \\(n_1\\) from both sides",
                      "Square both sides"
                    ],
                    "answer": 0,
                    "why": "Adding \\(n_2\\sin\\theta_2\\) isolates \\(n_2\\sin\\theta_2\\) on the left and \\(n_1\\sin\\theta_1\\) on the right."
                  }
                },
                {
                  "focus": ["AR", "RB", "theta1", "theta2"],
                  "move": {
                    "type": "swap"
                  },
                  "tex": "n_1\\sin\\theta_1 = n_2\\sin\\theta_2",
                  "note": "Swap sides to obtain Snell's law of refraction (Eq. 3.6)."
                }
              ]
            },
            {
              "type": "math",
              "label": "06 · §3.2 Examples",
              "title": "Paraboloidal and elliptical reflectors (Examples 3.1–3.2)",
              "tex": "S_1 P + S_2 P = \\text{constant} \\implies \\delta L_{\\text{op}} = 0",
              "body": "A paraboloid reflects parallel rays to its focus \\(S\\) (radio telescopes). An elliptical reflector sends every ray from focus \\(S_1\\) to focus \\(S_2\\) with stationary (constant) travel time (ruby laser)."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "When does geometrical optics accurately describe light propagation?",
              "options": [
                "When wavelength is much smaller than apertures",
                "When apertures are smaller than wavelength",
                "Only inside a vacuum chamber",
                "Only when refractive index is zero"
              ],
              "answer": 0,
              "why": "Neglecting wavelength works when openings are much larger than the wavelength of light."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "According to the modern Fermat's principle, the optical path of a ray is:",
              "options": [
                "Stationary for small path variations",
                "Always the longest possible path",
                "Always zero in every medium",
                "Independent of refractive index"
              ],
              "answer": 0,
              "why": "The ray path makes the optical path length stationary: a minimum, maximum, or constant."
            },
            {
              "type": "fill",
              "label": "Quiz · Fill in",
              "time": 45,
              "q": "In a homogeneous medium, light rays travel along ______ lines.",
              "answer": "straight",
              "why": "With constant refractive index, a straight line minimizes the optical path between two points."
            },
            {
              "type": "number",
              "label": "Quiz · Number",
              "time": 60,
              "q": "Find the optical path length for \\(4\\text{ cm}\\) in glass of \\(n = 1.5\\).",
              "answer": 6,
              "tolerance": 0.01,
              "unit": "cm",
              "why": "Optical path length equals \\(n \\times d = 1.5 \\times 4\\text{ cm} = 6\\text{ cm}\\)."
            }
          ]
        },
        {
          "id": "spherical-surface-refraction-reflection",
          "title": "Single spherical surface",
          "icon": "curve",
          "source": "Unit 2 · Ghatak §§4.2–4.3 (PDF pp. 80–82). Note: Section 4.1 is missing from the unit files and is not included.",
          "cards": [
            {
              "type": "intuition",
              "term": "paraxial-approximation",
              "title": "Why only rays close to the axis focus sharply",
              "meaning": "The paraxial approximation keeps only rays that make very small angles with the symmetry axis of a curved surface.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Paraxial ray making a small angle alpha1 with the optical axis at height h\"><line x1=\"16\" y1=\"105\" x2=\"244\" y2=\"105\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 132 24 Q 104 105 132 162\" class=\"lk\" stroke-width=\"2.4\" data-part=\"SPM\"/><line x1=\"118\" y1=\"56\" x2=\"118\" y2=\"105\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"h\"/><polyline points=\"28,105 118,56 226,105\" class=\"hk\" stroke-width=\"2.6\" data-part=\"OSI\"/><path d=\"M 56 90 A 32 32 0 0 1 60 105\" class=\"lk\" stroke-width=\"1.8\" data-part=\"alpha1\"/><path d=\"M 196 105 A 30 30 0 0 1 199 93\" class=\"lk\" stroke-width=\"1.8\" data-part=\"alpha2\"/><circle cx=\"28\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"O\"/><circle cx=\"118\" cy=\"56\" r=\"4\" class=\"h\" data-part=\"S\"/><circle cx=\"226\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"I\"/><text x=\"28\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"O\">O</text><text x=\"68\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"alpha1\">α₁</text><text x=\"126\" y=\"84\" font-size=\"11\" class=\"t\" data-part=\"h\">h</text><text x=\"118\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"226\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"I\">I</text><text x=\"130\" y=\"152\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"alpha1\">Small α₁: sin α₁ ≈ tan α₁ ≈ h/x</text></svg>",
              "picture": "Look at the small angle arc α₁ near O where height h divided by distance x gives the angle in radians.",
              "example": "At an angle of 0.1 rad (about 5.7°), sin(0.1) = 0.0998 and tan(0.1) = 0.1003, so sin φ₁ ≈ tan φ₁ ≈ φ₁.",
              "bridge": "Under this small-angle rule, all paraxial rays from object point O take equal time and meet at a single image point I."
            },
            {
              "type": "info",
              "label": "01 · §4.2 Definition",
              "title": "What is the paraxial approximation?",
              "defines": ["paraxial-approximation", "center-of-curvature"],
              "body": "The paraxial approximation assumes rays make very small angles with the optical axis so sine and tangent equal the angle in radians.",
              "tex": "\\sin\\phi_1 \\approx \\tan\\phi_1 \\approx \\phi_1",
              "examples": [
                "Small angles (rad)",
                "Single image point I",
                "Equal travel time"
              ]
            },
            {
              "type": "info",
              "label": "02 · §4.2.1 Sign convention",
              "title": "The Sign Convention at pole P",
              "body": "Rays are incident from the left. With pole P as origin, distances to the right are positive, to the left are negative, and upward heights are positive.",
              "examples": [
                "Left of P: negative",
                "Right of P: positive",
                "Upward: positive"
              ],
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Cartesian sign convention at spherical surface pole P\"><line x1=\"15\" y1=\"95\" x2=\"245\" y2=\"95\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 145 25 Q 110 95 145 165\" class=\"lk\" stroke-width=\"2.5\" data-part=\"SPM\"/><line x1=\"28\" y1=\"60\" x2=\"95\" y2=\"60\" class=\"hk\" stroke-width=\"2.5\" data-part=\"incident\"/><polygon points=\"95,55 105,60 95,65\" class=\"h\" data-part=\"incident\"/><circle cx=\"128\" cy=\"95\" r=\"4\" class=\"f\" data-part=\"P\"/><circle cx=\"205\" cy=\"95\" r=\"3.5\" class=\"f\" data-part=\"C\"/><text x=\"65\" y=\"48\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"incident\">Incident light</text><text x=\"62\" y=\"118\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"left\">u &lt; 0 (left)</text><text x=\"190\" y=\"118\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"right\">v, R &gt; 0 (right)</text><text x=\"122\" y=\"112\" text-anchor=\"end\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"205\" y=\"85\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"C\">C</text><text x=\"155\" y=\"44\" font-size=\"11\" class=\"t\" data-part=\"up\">+y upward</text><text x=\"155\" y=\"154\" font-size=\"11\" class=\"t\" data-part=\"down\">-y downward</text></svg>"
            },
            {
              "type": "derivation",
              "label": "03 · §4.2.2 Derivation",
              "title": "The Gaussian formula for a single spherical surface",
              "legend": "Spherical surface \\(SPM\\) separating \\(n_1, n_2\\) with object \\(O\\) at \\(x = -u\\), image \\(I\\) at \\(y = v\\), center \\(C\\) at \\(r = R\\), height \\(h\\) (Fig. 4.1(a)).",
              "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Paraxial refraction at a single spherical surface\"><line x1=\"14\" y1=\"105\" x2=\"246\" y2=\"105\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 128 24 Q 96 105 128 162\" class=\"lk\" stroke-width=\"2.5\" data-part=\"SPM\"/><line x1=\"114\" y1=\"48\" x2=\"114\" y2=\"105\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"h\"/><line x1=\"90\" y1=\"26\" x2=\"176\" y2=\"105\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"normal\"/><line x1=\"26\" y1=\"105\" x2=\"114\" y2=\"48\" class=\"hk\" stroke-width=\"2.5\" data-part=\"OS\"/><line x1=\"114\" y1=\"48\" x2=\"232\" y2=\"105\" class=\"lk\" stroke-width=\"2.5\" data-part=\"SI\"/><path d=\"M 48 91 A 26 26 0 0 1 52 105\" class=\"lk\" stroke-width=\"1.8\" data-part=\"alpha1\"/><path d=\"M 96 60 A 22 22 0 0 1 98 33\" class=\"lk\" stroke-width=\"1.8\" data-part=\"phi1\"/><path d=\"M 130 63 A 22 22 0 0 0 134 58\" class=\"lk\" stroke-width=\"1.8\" data-part=\"phi2\"/><path d=\"M 152 105 A 24 24 0 0 1 158 88\" class=\"lk\" stroke-width=\"1.8\" data-part=\"beta\"/><path d=\"M 206 105 A 26 26 0 0 1 209 94\" class=\"lk\" stroke-width=\"1.8\" data-part=\"alpha2\"/><circle cx=\"26\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"O\"/><circle cx=\"114\" cy=\"48\" r=\"4\" class=\"h\" data-part=\"S\"/><circle cx=\"176\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"C\"/><circle cx=\"232\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"I\"/><text x=\"24\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"O\">O</text><text x=\"58\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"alpha1\">α₁</text><text x=\"88\" y=\"48\" font-size=\"11\" class=\"t\" data-part=\"phi1\">φ₁</text><text x=\"138\" y=\"54\" font-size=\"11\" class=\"t\" data-part=\"phi2\">φ₂</text><text x=\"114\" y=\"36\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"S\">S</text><text x=\"122\" y=\"82\" font-size=\"11\" class=\"t\" data-part=\"h\">h</text><text x=\"112\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"144\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"beta\">β</text><text x=\"176\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"C\">C</text><text x=\"198\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"alpha2\">α₂</text><text x=\"232\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"I\">I</text><text x=\"70\" y=\"144\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"x\">x = -u</text><text x=\"146\" y=\"144\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"r\">r = R</text><text x=\"174\" y=\"164\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"y\">y = v</text><text x=\"46\" y=\"36\" font-size=\"12\" class=\"t\" data-part=\"OS\">n₁</text><text x=\"205\" y=\"36\" font-size=\"12\" class=\"t\" data-part=\"SI\">n₂</text></svg>",
              "phases": [
                {
                  "name": "Snell's law",
                  "why": "start from Snell's law and apply the paraxial approximation"
                },
                {
                  "name": "Incident angle",
                  "why": "express φ₁ from exterior angle of triangle OSC"
                },
                {
                  "name": "Refracted angle",
                  "why": "express φ₂ from exterior angle of triangle ISC"
                },
                {
                  "name": "Cancel height",
                  "why": "divide by h and collect distance terms"
                },
                {
                  "name": "Sign convention",
                  "why": "apply u = -x, v = y, and R = r"
                }
              ],
              "steps": [
                {
                  "phase": "Snell's law",
                  "focus": ["OS", "SI", "phi1", "phi2"],
                  "tex": "n_1\\sin\\phi_1 = n_2\\sin\\phi_2",
                  "note": "Start from Snell's law at point \\(S\\) on spherical surface \\(SPM\\) (Eq. 4.1)."
                },
                {
                  "focus": ["phi1", "phi2", "normal"],
                  "move": {
                    "type": "substitute",
                    "by": "\\sin\\phi_1 \\approx \\phi_1,\\,\\sin\\phi_2 \\approx \\phi_2"
                  },
                  "tex": "n_1\\phi_1 = n_2\\phi_2",
                  "note": "Use the paraxial approximation \\(\\sin\\phi \\approx \\phi\\) for small angles in radians.",
                  "ask": {
                    "q": "Why can \\(\\sin\\phi_1\\) and \\(\\sin\\phi_2\\) be replaced by \\(\\phi_1\\) and \\(\\phi_2\\)?",
                    "options": [
                      "Paraxial rays make small angles",
                      "Refractive indices are equal",
                      "The surface is a plane mirror",
                      "The angles are ninety degrees"
                    ],
                    "answer": 0,
                    "why": "In the paraxial approximation, all angles in radians are small so \\(\\sin\\phi \\approx \\phi\\)."
                  }
                },
                {
                  "phase": "Incident angle",
                  "focus": ["OS", "normal", "phi1", "alpha1", "beta"],
                  "move": {
                    "type": "substitute",
                    "by": "\\phi_1 = \\beta + \\alpha_1"
                  },
                  "tex": "n_1(\\beta + \\alpha_1) = n_2\\phi_2",
                  "note": "In triangle \\(OSC\\), exterior angle \\(\\phi_1\\) equals \\(\\beta + \\alpha_1\\).",
                  "ask": {
                    "q": "In triangle \\(OSC\\), what does exterior angle \\(\\phi_1\\) equal?",
                    "options": [
                      "\\(\\beta + \\alpha_1\\)",
                      "\\(\\beta - \\alpha_1\\)",
                      "\\(\\alpha_1 - \\beta\\)",
                      "\\(\\alpha_1 + \\alpha_2\\)"
                    ],
                    "answer": 0,
                    "why": "Angle \\(\\phi_1\\) is exterior to interior angles \\(\\alpha_1\\) at \\(O\\) and \\(\\beta\\) at \\(C\\)."
                  }
                },
                {
                  "focus": ["h", "r", "x", "alpha1", "beta"],
                  "move": {
                    "type": "substitute",
                    "by": "\\beta = \\frac{h}{r},\\,\\alpha_1 = \\frac{h}{x}"
                  },
                  "tex": "n_1\\left(\\frac{h}{r} + \\frac{h}{x}\\right) = n_2\\phi_2",
                  "note": "Substitute \\(\\beta \\approx \\tan\\beta = h/r\\) and \\(\\alpha_1 \\approx \\tan\\alpha_1 = h/x\\) (Eq. 4.2)."
                },
                {
                  "phase": "Refracted angle",
                  "focus": ["SI", "normal", "phi2", "beta", "alpha2"],
                  "move": {
                    "type": "substitute",
                    "by": "\\phi_2 = \\beta - \\alpha_2"
                  },
                  "tex": "n_1\\left(\\frac{h}{r} + \\frac{h}{x}\\right) = n_2(\\beta - \\alpha_2)",
                  "note": "In triangle \\(ISC\\), exterior angle \\(\\beta = \\phi_2 + \\alpha_2\\), so \\(\\phi_2 = \\beta - \\alpha_2\\)."
                },
                {
                  "focus": ["h", "r", "y", "beta", "alpha2"],
                  "move": {
                    "type": "substitute",
                    "by": "\\beta = \\frac{h}{r},\\,\\alpha_2 = \\frac{h}{y}"
                  },
                  "tex": "n_1\\left(\\frac{h}{r} + \\frac{h}{x}\\right) = n_2\\left(\\frac{h}{r} - \\frac{h}{y}\\right)",
                  "note": "Substitute \\(\\beta \\approx h/r\\) and \\(\\alpha_2 \\approx \\tan\\alpha_2 = h/y\\) (Eq. 4.3)."
                },
                {
                  "phase": "Cancel height",
                  "focus": ["h", "OS", "SI"],
                  "move": {
                    "type": "divide",
                    "by": "h"
                  },
                  "tex": "\\frac{n_1}{r} + \\frac{n_1}{x} = \\frac{n_2}{r} - \\frac{n_2}{y}",
                  "note": "Divide both sides by \\(h\\) so the ray height cancels out.",
                  "ask": {
                    "q": "Why does dividing by \\(h\\) show all paraxial rays focus together?",
                    "options": [
                      "The equation no longer depends on \\(h\\)",
                      "The radius \\(r\\) becomes zero",
                      "The refractive index cancels out",
                      "The object distance becomes infinite"
                    ],
                    "answer": 0,
                    "why": "Once \\(h\\) cancels, every paraxial ray gives the same image distance \\(y\\)."
                  }
                },
                {
                  "focus": ["x", "y", "r"],
                  "move": {
                    "type": "rearrange"
                  },
                  "tex": "\\frac{n_2}{y} + \\frac{n_1}{x} = \\frac{n_2 - n_1}{r}",
                  "note": "Collect \\(x, y\\) terms on the left and \\(r\\) terms on the right (Eq. 4.4)."
                },
                {
                  "phase": "Sign convention",
                  "focus": ["x", "y", "r", "O", "I", "C"],
                  "move": {
                    "type": "substitute",
                    "by": "x = -u,\\,y = v,\\,r = R"
                  },
                  "tex": "\\frac{n_2}{v} - \\frac{n_1}{u} = \\frac{n_2 - n_1}{R}",
                  "note": "Apply the sign convention \\(u = -x, v = y, R = r\\) to get the Gaussian formula (Eq. 4.5).",
                  "ask": {
                    "q": "Since object \\(O\\) lies left of pole \\(P\\), what replaces \\(x\\)?",
                    "options": [
                      "\\(-u\\)",
                      "\\(+u\\)",
                      "\\(-v\\)",
                      "\\(+R\\)"
                    ],
                    "answer": 0,
                    "why": "Distances to the left of \\(P\\) are negative, so \\(u = -x\\) and \\(x = -u\\)."
                  }
                }
              ]
            },
            {
              "type": "intuition",
              "term": "meridional-ray",
              "title": "Rays that stay in one flat slice versus skew rays",
              "meaning": "Meridional rays stay inside the plane that contains the optical axis, whereas skew rays twist out of a single plane.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Meridional ray staying inside the axial plane versus a skew ray twisting out\"><polygon points=\"24,118 76,34 236,34 184,118\" class=\"s ok\" data-part=\"plane\"/><line x1=\"34\" y1=\"76\" x2=\"226\" y2=\"76\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><polyline points=\"52,76 128,48 204,76\" class=\"hk\" stroke-width=\"2.6\" data-part=\"meridional\"/><path d=\"M 76 67 A 26 26 0 0 1 78 76\" class=\"lk\" stroke-width=\"1.8\" data-part=\"meridional\"/><polyline points=\"64,108 134,58 196,144\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.8\" data-part=\"skew\"/><circle cx=\"52\" cy=\"76\" r=\"4\" class=\"h\" data-part=\"C1\"/><circle cx=\"204\" cy=\"76\" r=\"3.5\" class=\"f\" data-part=\"C2\"/><text x=\"46\" y=\"92\" font-size=\"11\" class=\"t\" data-part=\"C1\">C₁</text><text x=\"208\" y=\"92\" font-size=\"11\" class=\"t\" data-part=\"C2\">C₂</text><text x=\"134\" y=\"44\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"meridional\">Meridional ray (in plane)</text><text x=\"148\" y=\"158\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"skew\">Skew ray (leaves plane)</text></svg>",
              "picture": "Look at the amber meridional ray inside the flat axial slice, while the dashed skew ray leaves the slice.",
              "example": "Every ray starting from an object point on the optical axis is automatically a meridional ray.",
              "bridge": "When a system has two spherical surfaces, the line joining their centers C₁ and C₂ defines the optical axis."
            },
            {
              "type": "info",
              "label": "04 · §4.2.2 Definition",
              "title": "What is a meridional ray?",
              "defines": ["meridional-ray"],
              "body": "A meridional ray is a light ray confined to a single plane containing the optical axis, unlike a non-planar skew ray.",
              "examples": [
                "In axis plane",
                "On-axis point: all meridional",
                "Off-axis tilt: skew"
              ]
            },
            {
              "type": "derivation",
              "label": "05 · §4.3 Derivation",
              "title": "Reflection by a single spherical surface",
              "legend": "Spherical mirror \\(SPM\\) with object \\(O\\), center \\(C\\), and image \\(I\\) to the left of pole \\(P\\) (\\(u = -x, v = -y, R = -r\\), Fig. 4.3).",
              "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Paraxial reflection at a spherical mirror\"><line x1=\"14\" y1=\"105\" x2=\"240\" y2=\"105\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 195 24 Q 222 105 195 162\" class=\"lk\" stroke-width=\"2.5\" data-part=\"SPM\"/><line x1=\"204\" y1=\"46\" x2=\"204\" y2=\"105\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"h\"/><line x1=\"118\" y1=\"105\" x2=\"204\" y2=\"46\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"CS\"/><line x1=\"28\" y1=\"105\" x2=\"204\" y2=\"46\" class=\"hk\" stroke-width=\"2.5\" data-part=\"OS\"/><line x1=\"204\" y1=\"46\" x2=\"154\" y2=\"105\" class=\"lk\" stroke-width=\"2.5\" data-part=\"SI\"/><path d=\"M 55 96 A 28 28 0 0 1 56 105\" class=\"lk\" stroke-width=\"1.8\" data-part=\"alpha1\"/><path d=\"M 140 90 A 26 26 0 0 1 144 105\" class=\"lk\" stroke-width=\"1.8\" data-part=\"beta\"/><path d=\"M 170 86 A 24 24 0 0 1 178 105\" class=\"lk\" stroke-width=\"1.8\" data-part=\"alpha2\"/><path d=\"M 180 54 A 25 25 0 0 0 190 66\" class=\"lk\" stroke-width=\"1.8\" data-part=\"phi\"/><circle cx=\"28\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"O\"/><circle cx=\"118\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"C\"/><circle cx=\"154\" cy=\"105\" r=\"3.5\" class=\"f\" data-part=\"I\"/><circle cx=\"204\" cy=\"46\" r=\"4\" class=\"h\" data-part=\"S\"/><text x=\"28\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"O\">O</text><text x=\"66\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"alpha1\">α₁</text><text x=\"118\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"C\">C</text><text x=\"134\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"beta\">β</text><text x=\"154\" y=\"122\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"I\">I</text><text x=\"174\" y=\"98\" font-size=\"11\" class=\"t\" data-part=\"alpha2\">α₂</text><text x=\"204\" y=\"34\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"S\">S</text><text x=\"162\" y=\"52\" font-size=\"11\" class=\"t\" data-part=\"phi\">φ₁=φ₂</text><text x=\"214\" y=\"82\" font-size=\"11\" class=\"t\" data-part=\"h\">h</text><text x=\"214\" y=\"122\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"116\" y=\"144\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"x\">x = -u, r = -R, y = -v</text></svg>",
              "phases": [
                {
                  "name": "Reflection law",
                  "why": "equate angles of incidence and reflection at S"
                },
                {
                  "name": "Incident ray",
                  "why": "write φ₁ from triangle OSC and paraxial ratios"
                },
                {
                  "name": "Reflected ray",
                  "why": "write φ₂ from triangle CSI and paraxial ratios"
                },
                {
                  "name": "Cancel height",
                  "why": "divide by h and collect 1/x + 1/y"
                },
                {
                  "name": "Sign convention",
                  "why": "substitute u = -x, v = -y, R = -r"
                }
              ],
              "steps": [
                {
                  "phase": "Reflection law",
                  "focus": ["OS", "SI", "phi", "S"],
                  "tex": "\\phi_1 = \\phi_2",
                  "note": "At point \\(S\\), the angle of incidence equals the angle of reflection."
                },
                {
                  "phase": "Incident ray",
                  "focus": ["OS", "CS", "alpha1", "beta", "phi"],
                  "move": {
                    "type": "substitute",
                    "by": "\\phi_1 = \\beta - \\alpha_1"
                  },
                  "tex": "\\beta - \\alpha_1 = \\phi_2",
                  "note": "In triangle \\(OSC\\), exterior angle \\(\\beta = \\alpha_1 + \\phi_1\\), so \\(\\phi_1 = \\beta - \\alpha_1\\).",
                  "ask": {
                    "q": "In triangle \\(OSC\\), how is \\(\\phi_1\\) related to \\(\\beta\\) and \\(\\alpha_1\\)?",
                    "options": [
                      "\\(\\phi_1 = \\beta - \\alpha_1\\)",
                      "\\(\\phi_1 = \\beta + \\alpha_1\\)",
                      "\\(\\phi_1 = \\alpha_1 - \\beta\\)",
                      "\\(\\phi_1 = 2\\beta\\)"
                    ],
                    "answer": 0,
                    "why": "Exterior angle \\(\\beta\\) equals \\(\\alpha_1 + \\phi_1\\), so \\(\\phi_1 = \\beta - \\alpha_1\\)."
                  }
                },
                {
                  "focus": ["h", "x", "alpha1", "beta"],
                  "move": {
                    "type": "substitute",
                    "by": "\\beta = \\frac{h}{r},\\,\\alpha_1 = \\frac{h}{x}"
                  },
                  "tex": "\\frac{h}{r} - \\frac{h}{x} = \\phi_2",
                  "note": "Replace small angles \\(\\beta\\) and \\(\\alpha_1\\) by \\(h/r\\) and \\(h/x\\)."
                },
                {
                  "phase": "Reflected ray",
                  "focus": ["SI", "CS", "alpha2", "beta", "phi"],
                  "move": {
                    "type": "substitute",
                    "by": "\\phi_2 = \\alpha_2 - \\beta"
                  },
                  "tex": "\\frac{h}{r} - \\frac{h}{x} = \\alpha_2 - \\beta",
                  "note": "In triangle \\(CSI\\), exterior angle \\(\\alpha_2 = \\beta + \\phi_2\\), so \\(\\phi_2 = \\alpha_2 - \\beta\\)."
                },
                {
                  "focus": ["h", "alpha2", "beta"],
                  "move": {
                    "type": "substitute",
                    "by": "\\alpha_2 = \\frac{h}{y},\\,\\beta = \\frac{h}{r}"
                  },
                  "tex": "\\frac{h}{r} - \\frac{h}{x} = \\frac{h}{y} - \\frac{h}{r}",
                  "note": "Replace small angles \\(\\alpha_2\\) and \\(\\beta\\) by \\(h/y\\) and \\(h/r\\).",
                  "ask": {
                    "q": "What replaces \\(\\alpha_2\\) in the paraxial approximation?",
                    "options": [
                      "\\(h / y\\)",
                      "\\(y / h\\)",
                      "\\(h / x\\)",
                      "\\(h / r\\)"
                    ],
                    "answer": 0,
                    "why": "Reflected ray \\(SI\\) meets the axis at distance \\(y\\), so \\(\\alpha_2 \\approx h / y\\)."
                  }
                },
                {
                  "phase": "Cancel height",
                  "focus": ["h", "OS", "SI"],
                  "move": {
                    "type": "divide",
                    "by": "h"
                  },
                  "tex": "\\frac{1}{r} - \\frac{1}{x} = \\frac{1}{y} - \\frac{1}{r}",
                  "note": "Divide both sides by \\(h\\).",
                  "ask": {
                    "q": "What is the next step to eliminate the ray height \\(h\\)?",
                    "options": [
                      "Divide both sides by \\(h\\)",
                      "Multiply both sides by \\(r\\)",
                      "Set \\(x = y\\)",
                      "Differentiate with respect to \\(h\\)"
                    ],
                    "answer": 0,
                    "why": "Every term has \\(h\\) in the numerator, so dividing by \\(h\\) removes it."
                  }
                },
                {
                  "focus": ["x", "CS"],
                  "move": {
                    "type": "rearrange"
                  },
                  "tex": "\\frac{1}{x} + \\frac{1}{y} = \\frac{2}{r}",
                  "note": "Collect \\(1/x + 1/y\\) on the left and \\(2/r\\) on the right (Eq. 4.6)."
                },
                {
                  "phase": "Sign convention",
                  "focus": ["x", "O", "C", "I"],
                  "move": {
                    "type": "substitute",
                    "by": "x = -u,\\,y = -v,\\,r = -R"
                  },
                  "tex": "-\\frac{1}{u} - \\frac{1}{v} = -\\frac{2}{R}",
                  "note": "Since \\(O, I, C\\) lie to the left of \\(P\\), substitute \\(x = -u, y = -v, r = -R\\)."
                },
                {
                  "focus": ["OS", "SI", "CS"],
                  "move": {
                    "type": "negate"
                  },
                  "tex": "\\frac{1}{u} + \\frac{1}{v} = \\frac{2}{R}",
                  "note": "Negate both sides to obtain the mirror equation (Eq. 4.7).",
                  "ask": {
                    "q": "Which substitution in the refraction formula also gives the mirror equation?",
                    "options": [
                      "\\(n_2 = -n_1\\)",
                      "\\(n_2 = n_1\\)",
                      "\\(n_2 = 0\\)",
                      "\\(R = \\infty\\)"
                    ],
                    "answer": 0,
                    "why": "Setting \\(n_2 = -n_1\\) in Eq. (4.5) turns Snell's law into reflection and yields Eq. (4.7)."
                  }
                }
              ]
            },
            {
              "type": "math",
              "label": "06 · §4.2.2 Example",
              "title": "Worked example: refraction at a spherical surface (Example 4.1)",
              "tex": "\\frac{1.5}{v} - \\frac{1.0}{-40} = \\frac{1.5 - 1.0}{+15} \\implies v = +180\\text{ cm}",
              "body": "An object in air (\\(n_1 = 1.0\\)) lies \\(40\\text{ cm}\\) left of a glass surface (\\(n_2 = 1.5, R = +15\\text{ cm}\\)). The first surface forms an image at \\(+180\\text{ cm}\\)."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "In the Cartesian sign convention, when is object distance \\(u\\) positive?",
              "options": [
                "When incident rays converge right of P",
                "When a real object sits left of P",
                "Whenever the surface is concave",
                "Whenever the image is inverted"
              ],
              "answer": 0,
              "why": "Distances to the right of pole \\(P\\) are positive, which happens for a virtual object."
            },
            {
              "type": "fill",
              "label": "Quiz · Fill in",
              "time": 45,
              "q": "Off-axis rays that do not stay in a single plane are called ______ rays.",
              "answer": "skew",
              "why": "Rays confined to the axial plane are meridional rays; non-planar rays are skew rays."
            },
            {
              "type": "number",
              "label": "Quiz · Number",
              "time": 60,
              "q": "For a concave mirror with \\(R = -60\\text{ cm}\\) and \\(u = -80\\text{ cm}\\), find \\(v\\).",
              "answer": -48,
              "tolerance": 0.1,
              "unit": "cm",
              "why": "\\(\\frac{1}{v} = \\frac{2}{-60} - \\frac{1}{-80} = -\\frac{1}{30} + \\frac{1}{80} = -\\frac{5}{240}\\), so \\(v = -48\\text{ cm}\\) (Example 4.2)."
            }
          ]
        }
      ]
    },
    {
      "short": "Thin Lens",
      "title": "Thin Lenses, Foci & Magnification",
      "sheets": [
        {
          "id": "thin-lens-foci-focal-length",
          "title": "Thin lens & principal foci",
          "icon": "lens",
          "source": "Unit 3 · Ghatak §§4.4–4.5 (PDF pp. 83–84)",
          "cards": [
            {
              "type": "intuition",
              "term": "thin-lens",
              "title": "Two spherical surfaces pressed close together",
              "meaning": "A thin lens is a transparent medium bounded by two spherical surfaces whose thickness is negligible compared to all other distances.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Thin lens of tiny thickness t compared with distances u and v measured from center P\"><line x1=\"12\" y1=\"96\" x2=\"248\" y2=\"96\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 118 26 Q 104 96 118 164 Q 132 96 118 26\" class=\"s ok\" data-part=\"lens\"/><polyline points=\"26,96 118,46 218,96\" class=\"hk\" stroke-width=\"2.6\" data-part=\"ray\"/><path d=\"M 50 83 A 28 28 0 0 1 54 96\" class=\"lk\" stroke-width=\"1.8\" data-part=\"u\"/><path d=\"M 192 96 A 26 26 0 0 1 195 84\" class=\"lk\" stroke-width=\"1.8\" data-part=\"v\"/><circle cx=\"26\" cy=\"96\" r=\"3.5\" class=\"f\" data-part=\"O\"/><circle cx=\"118\" cy=\"96\" r=\"4\" class=\"h\" data-part=\"P\"/><circle cx=\"218\" cy=\"96\" r=\"3.5\" class=\"f\" data-part=\"I\"/><text x=\"26\" y=\"114\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"O\">O</text><text x=\"118\" y=\"20\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"lens\">t ≪ |u|, |v|</text><text x=\"114\" y=\"114\" text-anchor=\"end\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"218\" y=\"114\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"I\">I</text><text x=\"72\" y=\"138\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"u\">u (from P)</text><text x=\"168\" y=\"138\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"v\">v (from P)</text></svg>",
              "picture": "Look at the thin lens at P: thickness t is so small that both u and v are measured from P.",
              "example": "Because thickness t is tiny, we measure object distance u and image distance v from one shared center P.",
              "bridge": "The first surface forms an intermediate image Q at v', which immediately acts as the object for the second surface to form final image I at v."
            },
            {
              "type": "info",
              "label": "01 · §4.4 Definition",
              "title": "What is a thin spherical lens?",
              "defines": ["thin-lens"],
              "body": "A thin spherical lens is a medium bounded by two spherical refracting surfaces whose thickness t is very small compared to object, image, and curvature distances.",
              "tex": "t \\ll |u|,\\,|v|,\\,|R_1|,\\,|R_2|",
              "examples": [
                "Two spherical surfaces",
                "Axis joins C₁ and C₂",
                "Measured from P"
              ]
            },
            {
              "type": "derivation",
              "label": "02 · §4.4 Derivation",
              "title": "The thin lens and Lensmaker's formula",
              "legend": "Lens of index \\(n_2\\) in medium \\(n_1\\) with radii \\(R_1, R_2\\), intermediate image \\(Q\\) at \\(v'\\), final image \\(I\\) at \\(v\\), and \\(n = n_2 / n_1\\) (Fig. 4.5).",
              "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Successive refractions at the two surfaces of a thin lens\"><line x1=\"12\" y1=\"98\" x2=\"248\" y2=\"98\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 110 28 Q 92 98 110 164\" class=\"lk\" stroke-width=\"2\" data-part=\"surf1\"/><path d=\"M 118 28 Q 136 98 118 164\" class=\"lk\" stroke-width=\"2\" data-part=\"surf2\"/><line x1=\"118\" y1=\"50\" x2=\"238\" y2=\"98\" class=\"gk\" stroke-dasharray=\"4 4\" stroke-width=\"1.5\" data-part=\"rayQ\"/><line x1=\"24\" y1=\"98\" x2=\"110\" y2=\"50\" class=\"hk\" stroke-width=\"2.5\" data-part=\"rayO\"/><line x1=\"110\" y1=\"50\" x2=\"188\" y2=\"98\" class=\"lk\" stroke-width=\"2.5\" data-part=\"rayI\"/><path d=\"M 46 86 A 25 25 0 0 1 49 98\" class=\"lk\" stroke-width=\"1.8\" data-part=\"rayO\"/><path d=\"M 166 98 A 22 22 0 0 1 169 86\" class=\"lk\" stroke-width=\"1.8\" data-part=\"rayI\"/><circle cx=\"24\" cy=\"98\" r=\"3.5\" class=\"f\" data-part=\"O\"/><circle cx=\"114\" cy=\"98\" r=\"3.5\" class=\"f\" data-part=\"P\"/><circle cx=\"188\" cy=\"98\" r=\"4\" class=\"h\" data-part=\"I\"/><circle cx=\"238\" cy=\"98\" r=\"3.5\" class=\"f\" data-part=\"Q\"/><text x=\"24\" y=\"115\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"O\">O</text><text x=\"68\" y=\"115\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"u\">u &lt; 0</text><text x=\"114\" y=\"22\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"n2\">n₂</text><text x=\"60\" y=\"36\" font-size=\"12\" class=\"t\" data-part=\"n1\">n₁</text><text x=\"175\" y=\"36\" font-size=\"12\" class=\"t\" data-part=\"n1\">n₁</text><text x=\"114\" y=\"115\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"P\">P</text><text x=\"152\" y=\"115\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"v\">v</text><text x=\"188\" y=\"115\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"I\">I</text><text x=\"238\" y=\"115\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"vprime\">Q (v')</text><text x=\"130\" y=\"152\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"R1R2\">R₁ &gt; 0, R₂ &lt; 0</text></svg>",
              "phases": [
                {
                  "name": "First surface",
                  "why": "refraction at R₁ from n₁ into n₂ forms image Q at v'"
                },
                {
                  "name": "Second surface",
                  "why": "refraction at R₂ from n₂ into n₁ takes Q at v' to I at v"
                },
                {
                  "name": "Combine surfaces",
                  "why": "add the two surface equations to eliminate v'"
                },
                {
                  "name": "Relative index",
                  "why": "divide by n₁ and define n = n₂ / n₁"
                },
                {
                  "name": "Focal length",
                  "why": "define focal length f by Lensmaker's formula"
                }
              ],
              "steps": [
                {
                  "phase": "First surface",
                  "focus": ["surf1", "rayO", "rayQ", "u", "vprime"],
                  "tex": "\\frac{n_2}{v'} - \\frac{n_1}{u} = \\frac{n_2 - n_1}{R_1}",
                  "note": "First surface \\(R_1\\) refracts light from \\(n_1\\) into \\(n_2\\), forming \\(Q\\) at \\(v'\\) (Eq. 4.8)."
                },
                {
                  "phase": "Second surface",
                  "focus": ["surf2", "rayQ", "rayI", "vprime", "v"],
                  "move": {
                    "type": "rearrange",
                    "label": "Write second surface refraction (Eq. 4.9)"
                  },
                  "tex": "\\frac{n_1}{v} - \\frac{n_2}{v'} = \\frac{n_1 - n_2}{R_2}",
                  "note": "Point \\(Q\\) at \\(v'\\) acts as object for second surface \\(R_2\\) from \\(n_2\\) into \\(n_1\\) (Eq. 4.9).",
                  "ask": {
                    "q": "For the second surface \\(R_2\\), what acts as its object distance?",
                    "options": [
                      "Intermediate distance \\(v'\\)",
                      "Original distance \\(u\\)",
                      "Radius \\(R_1\\)",
                      "Thickness \\(t = 0\\)"
                    ],
                    "answer": 0,
                    "why": "The image \\(Q\\) formed by the first surface at \\(v'\\) serves as the object for the second surface."
                  }
                },
                {
                  "phase": "Combine surfaces",
                  "focus": ["surf1", "surf2", "rayI", "u", "v"],
                  "move": {
                    "type": "add",
                    "by": "\\frac{n_2}{v'} - \\frac{n_1}{u}"
                  },
                  "tex": "\\frac{n_1}{v} - \\frac{n_1}{u} = \\frac{n_2 - n_1}{R_1} + \\frac{n_1 - n_2}{R_2}",
                  "note": "Add Eqs. (4.8) and (4.9) so \\(+n_2/v'\\) and \\(-n_2/v'\\) cancel out.",
                  "ask": {
                    "q": "Why do we add Eqs. (4.8) and (4.9) together?",
                    "options": [
                      "To cancel intermediate distance \\(v'\\)",
                      "To cancel object distance \\(u\\)",
                      "To make \\(R_1 = R_2\\)",
                      "To set \\(n_1 = 0\\)"
                    ],
                    "answer": 0,
                    "why": "Adding \\(+n_2/v'\\) and \\(-n_2/v'\\) eliminates the intermediate image position \\(v'\\)."
                  }
                },
                {
                  "focus": ["surf1", "surf2", "R1R2"],
                  "move": {
                    "type": "factor"
                  },
                  "tex": "\\frac{n_1}{v} - \\frac{n_1}{u} = (n_2 - n_1)\\left(\\frac{1}{R_1} - \\frac{1}{R_2}\\right)",
                  "note": "Factor \\((n_2 - n_1)\\) on the right, flipping the sign on \\(1/R_2\\).",
                  "ask": {
                    "q": "When \\((n_2 - n_1)\\) is factored out of \\((n_1 - n_2)/R_2\\), what remains?",
                    "options": [
                      "\\(-1 / R_2\\)",
                      "\\(+1 / R_2\\)",
                      "\\(-R_2\\)",
                      "\\(n_1 / R_2\\)"
                    ],
                    "answer": 0,
                    "why": "Since \\(n_1 - n_2 = -(n_2 - n_1)\\), factoring out \\((n_2 - n_1)\\) leaves \\(-1/R_2\\)."
                  }
                },
                {
                  "phase": "Relative index",
                  "focus": ["n1", "n2", "R1R2"],
                  "move": {
                    "type": "divide",
                    "by": "n_1"
                  },
                  "tex": "\\frac{1}{v} - \\frac{1}{u} = \\left(\\frac{n_2}{n_1} - 1\\right)\\left(\\frac{1}{R_1} - \\frac{1}{R_2}\\right)",
                  "note": "Divide both sides by surrounding refractive index \\(n_1\\)."
                },
                {
                  "focus": ["n1", "n2", "R1R2"],
                  "move": {
                    "type": "substitute",
                    "by": "n = \\frac{n_2}{n_1}"
                  },
                  "tex": "\\frac{1}{v} - \\frac{1}{u} = (n - 1)\\left(\\frac{1}{R_1} - \\frac{1}{R_2}\\right)",
                  "note": "Write \\(n = n_2 / n_1\\) to obtain the thin lens formula (Eq. 4.10)."
                },
                {
                  "phase": "Focal length",
                  "focus": ["rayI", "u", "v", "I"],
                  "move": {
                    "type": "define",
                    "by": "\\frac{1}{f} = (n - 1)\\left(\\frac{1}{R_1} - \\frac{1}{R_2}\\right)"
                  },
                  "tex": "\\frac{1}{v} - \\frac{1}{u} = \\frac{1}{f}",
                  "note": "Define focal length \\(f\\) by Eq. (4.12) to get Eq. (4.11).",
                  "ask": {
                    "q": "When \\(u = -\\infty\\) (incident parallel rays), what does \\(v\\) equal?",
                    "options": [
                      "\\(f\\)",
                      "\\(0\\)",
                      "\\(-f\\)",
                      "\\(R_1\\)"
                    ],
                    "answer": 0,
                    "why": "Setting \\(1/u = 0\\) in \\(1/v - 1/u = 1/f\\) gives \\(v = f\\)."
                  }
                }
              ]
            },
            {
              "type": "info",
              "label": "03 · §4.4 Surrounding medium",
              "title": "Converging and diverging lenses in different media",
              "body": "For a biconvex lens (R₁ > 0, R₂ < 0), (1/R₁ - 1/R₂) is positive. It converges light when n₂ > n₁, but diverges light when placed in a medium with n₁ > n₂ (Fig. 4.7).",
              "examples": [
                "n₂ > n₁: biconvex f > 0",
                "n₂ < n₁: biconvex f < 0",
                "n₂ < n₁: biconcave f > 0"
              ],
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Biconvex lens converging when n2 is greater than n1 and diverging when n2 is less than n1\"><line x1=\"14\" y1=\"50\" x2=\"120\" y2=\"50\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"axis1\"/><path d=\"M 62 18 Q 50 50 62 82 Q 74 50 62 18\" class=\"s ok\" data-part=\"conv\"/><polyline points=\"18,32 62,32 108,50\" class=\"lk\" stroke-width=\"2\" data-part=\"conv\"/><polyline points=\"18,68 62,68 108,50\" class=\"lk\" stroke-width=\"2\" data-part=\"conv\"/><circle cx=\"108\" cy=\"50\" r=\"3.5\" class=\"f\" data-part=\"conv\"/><text x=\"62\" y=\"100\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"conv\">n₂ &gt; n₁: converges</text><line x1=\"140\" y1=\"50\" x2=\"246\" y2=\"50\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"axis2\"/><path d=\"M 192 18 Q 180 50 192 82 Q 204 50 192 18\" class=\"s ok\" data-part=\"div\"/><polyline points=\"148,32 192,32 238,16\" class=\"hk\" stroke-width=\"2.5\" data-part=\"div\"/><polyline points=\"148,68 192,68 238,84\" class=\"lk\" stroke-width=\"2\" data-part=\"div\"/><line x1=\"156\" y1=\"50\" x2=\"192\" y2=\"32\" class=\"gk\" stroke-dasharray=\"3 3\" stroke-width=\"1.5\" data-part=\"div\"/><circle cx=\"156\" cy=\"50\" r=\"4\" class=\"h\" data-part=\"div\"/><text x=\"192\" y=\"100\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"div\">n₂ &lt; n₁: diverges</text><text x=\"130\" y=\"148\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"formula\">1/f = (n₂/n₁ - 1)(1/R₁ - 1/R₂)</text></svg>"
            },
            {
              "type": "intuition",
              "term": "principal-focus",
              "title": "The two special focal points of any lens",
              "meaning": "The first principal focus F₁ turns rays from a point into parallel rays, while the second principal focus F₂ collects incoming parallel rays to a point.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"First principal focus F1 and second principal focus F2 of a converging lens\"><line x1=\"12\" y1=\"90\" x2=\"248\" y2=\"90\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 130 20 Q 116 90 130 160 Q 144 90 130 20\" class=\"s ok\" data-part=\"lens\"/><polyline points=\"56,90 130,136 238,136\" class=\"lk\" stroke-width=\"2\" data-part=\"ray1\"/><polyline points=\"22,44 130,44 204,90\" class=\"hk\" stroke-width=\"2.6\" data-part=\"ray2\"/><path d=\"M 76 90 A 20 20 0 0 1 73 101\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F1\"/><path d=\"M 184 90 A 20 20 0 0 1 187 79\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F2\"/><circle cx=\"56\" cy=\"90\" r=\"3.5\" class=\"f\" data-part=\"F1\"/><circle cx=\"130\" cy=\"90\" r=\"3.5\" class=\"f\" data-part=\"P\"/><circle cx=\"204\" cy=\"90\" r=\"4\" class=\"h\" data-part=\"F2\"/><text x=\"56\" y=\"78\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"F1\">F₁</text><text x=\"124\" y=\"106\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"P\">P</text><text x=\"204\" y=\"108\" text-anchor=\"middle\" font-size=\"12\" class=\"t\" data-part=\"F2\">F₂</text><text x=\"80\" y=\"36\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"ray2\">Ray 2 (parallel → F₂)</text><text x=\"184\" y=\"152\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"ray1\">Ray 1 (F₁ → parallel)</text><text x=\"92\" y=\"122\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F1\">f₁ &lt; 0</text><text x=\"168\" y=\"78\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F2\">f₂ &gt; 0</text></svg>",
              "picture": "Look at Ray 1 from F₁ emerging parallel, and parallel Ray 2 meeting the axis at F₂.",
              "example": "For a converging lens of focal length 20 cm in air, F₁ sits at f₁ = -20 cm (left) and F₂ sits at f₂ = +20 cm (right).",
              "bridge": "Setting v = ∞ gives u = f₁ (first focal length), and setting u = -∞ gives v = f₂ (second focal length)."
            },
            {
              "type": "info",
              "label": "04 · §4.5 Definition",
              "title": "What are the first and second principal foci?",
              "defines": ["principal-focus"],
              "body": "The first principal focus F₁ is the axial object point whose refracted rays emerge parallel (v = ∞), and the second principal focus F₂ is the axial image point for incident parallel rays (u = -∞).",
              "tex": "\\frac{1}{f_2} = -\\frac{1}{f_1} = \\frac{1}{f} \\quad (n_3 = n_1)",
              "examples": [
                "Converging: f₁<0, f₂>0",
                "Diverging: f₁>0, f₂<0",
                "Diff media: f₂/f₁ = -n₃/n₁"
              ]
            },
            {
              "type": "info",
              "label": "05 · §4.5 Ray tracing",
              "title": "Three principal rays for graphical construction",
              "body": "Ray 1 through F₁ emerges parallel to the axis. Ray 2 parallel to the axis passes through F₂. Ray 3 through lens center P passes undeviated (Fig. 4.8).",
              "examples": [
                "1: via F₁ → parallel",
                "2: parallel → via F₂",
                "3: via P → straight"
              ],
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Three principal rays tracing an image through a converging lens\"><line x1=\"10\" y1=\"92\" x2=\"250\" y2=\"92\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 125 22 Q 112 92 125 162 Q 138 92 125 22\" class=\"s ok\" data-part=\"lens\"/><line x1=\"36\" y1=\"92\" x2=\"36\" y2=\"44\" class=\"lk\" stroke-width=\"2.5\" data-part=\"OA\"/><line x1=\"214\" y1=\"92\" x2=\"214\" y2=\"140\" class=\"lk\" stroke-width=\"2.5\" data-part=\"IB\"/><polyline points=\"36,44 125,44 214,140\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ray2\"/><polyline points=\"36,44 76,92 125,140 214,140\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ray1\"/><line x1=\"36\" y1=\"44\" x2=\"214\" y2=\"140\" class=\"hk\" stroke-width=\"2.5\" data-part=\"ray3\"/><path d=\"M 103 80 A 25 25 0 0 0 100 92\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ray3\"/><path d=\"M 147 104 A 25 25 0 0 0 150 92\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ray3\"/><circle cx=\"76\" cy=\"92\" r=\"3.5\" class=\"f\" data-part=\"F1\"/><circle cx=\"125\" cy=\"92\" r=\"4\" class=\"h\" data-part=\"P\"/><circle cx=\"174\" cy=\"92\" r=\"3.5\" class=\"f\" data-part=\"F2\"/><text x=\"36\" y=\"36\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"OA\">A</text><text x=\"36\" y=\"108\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"OA\">O</text><text x=\"76\" y=\"108\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F1\">F₁</text><text x=\"120\" y=\"108\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"P\">P</text><text x=\"174\" y=\"84\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F2\">F₂</text><text x=\"214\" y=\"84\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"IB\">I</text><text x=\"214\" y=\"156\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"IB\">B</text><text x=\"82\" y=\"38\" font-size=\"11\" class=\"t\" data-part=\"ray2\">2</text><text x=\"96\" y=\"70\" font-size=\"11\" class=\"t\" data-part=\"ray3\">3</text><text x=\"96\" y=\"132\" font-size=\"11\" class=\"t\" data-part=\"ray1\">1</text></svg>"
            },
            {
              "type": "math",
              "label": "06 · §4.5 Different media",
              "title": "Thin lens with different media on its two sides (Eqs. 4.14–4.16)",
              "tex": "\\frac{n_3}{v} - \\frac{n_1}{u} = \\frac{n_2 - n_1}{R_1} + \\frac{n_3 - n_2}{R_2}",
              "body": "When medium \\(n_1\\) is on the left and \\(n_3\\) on the right, setting \\(v = \\infty\\) (Eq. 4.15) and \\(u = -\\infty\\) (Eq. 4.16) gives \\(f_2 / f_1 = -n_3 / n_1\\)."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "For a converging lens in air, what are the signs of \\(f_1\\) and \\(f_2\\)?",
              "options": [
                "\\(f_1 < 0\\) and \\(f_2 > 0\\)",
                "\\(f_1 > 0\\) and \\(f_2 < 0\\)",
                "Both \\(f_1\\) and \\(f_2\\) positive",
                "Both \\(f_1\\) and \\(f_2\\) negative"
              ],
              "answer": 0,
              "why": "For a converging lens, \\(F_1\\) lies on the left (\\(f_1 < 0\\)) and \\(F_2\\) lies on the right (\\(f_2 > 0\\))."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "How does a glass biconvex lens behave inside a liquid of higher refractive index?",
              "options": [
                "As a diverging lens",
                "As a converging lens",
                "As a plane mirror",
                "As an opaque screen"
              ],
              "answer": 0,
              "why": "When \\(n_2 < n_1\\), \\((n - 1)\\) becomes negative, so \\(f < 0\\) and the biconvex lens diverges light."
            },
            {
              "type": "fill",
              "label": "Quiz · Fill in",
              "time": 45,
              "q": "A paraxial ray passing through the center \\(P\\) of a thin lens travels ______.",
              "answer": "undeviated|straight",
              "why": "At \\(u = 0\\), the thin lens formula gives \\(v = 0\\), so the ray through \\(P\\) passes undeviated."
            },
            {
              "type": "number",
              "label": "Quiz · Number",
              "time": 60,
              "q": "Find \\(f\\) in air for \\(n = 1.5\\), \\(R_1 = +20\\text{ cm}\\), and \\(R_2 = -20\\text{ cm}\\).",
              "answer": 20,
              "tolerance": 0.1,
              "unit": "cm",
              "why": "\\(\\frac{1}{f} = (1.5 - 1)\\left(\\frac{1}{20} - \\frac{1}{-20}\\right) = 0.5 \\times \\frac{2}{20} = \\frac{1}{20}\\), so \\(f = 20\\text{ cm}\\)."
            }
          ]
        },
        {
          "id": "newton-formula-magnification",
          "title": "Newton formula & magnification",
          "icon": "graph",
          "source": "Unit 4 · Ghatak §§4.6–4.7 (PDF pp. 85–86)",
          "cards": [
            {
              "type": "info",
              "label": "01 · §4.6 Focal distances",
              "title": "Measuring object and image from the two foci",
              "body": "Newton's method measures object distance x₁ from F₁ (positive if right of F₁) and image distance x₂ from F₂ (positive if right of F₂), as in Fig. 4.8.",
              "examples": [
                "x₁ from F₁",
                "x₂ from F₂",
                "Right of focus: +"
              ],
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Distances x1 and x2 measured from principal foci F1 and F2\"><line x1=\"10\" y1=\"86\" x2=\"250\" y2=\"86\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 125 20 Q 113 86 125 152 Q 137 86 125 20\" class=\"s ok\" data-part=\"lens\"/><line x1=\"32\" y1=\"86\" x2=\"32\" y2=\"40\" class=\"lk\" stroke-width=\"2.5\" data-part=\"obj\"/><line x1=\"222\" y1=\"86\" x2=\"222\" y2=\"132\" class=\"lk\" stroke-width=\"2.5\" data-part=\"img\"/><polyline points=\"32,40 125,40 222,132\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ray2\"/><polyline points=\"32,40 80,86 125,132 222,132\" class=\"hk\" stroke-width=\"2.2\" data-part=\"ray1\"/><path d=\"M 64 71 A 22 22 0 0 0 58 86\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F1\"/><path d=\"M 96 101 A 22 22 0 0 0 102 86\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F1\"/><circle cx=\"80\" cy=\"86\" r=\"4\" class=\"h\" data-part=\"F1\"/><circle cx=\"170\" cy=\"86\" r=\"3.5\" class=\"f\" data-part=\"F2\"/><text x=\"32\" y=\"32\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"obj\">y</text><text x=\"32\" y=\"102\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"obj\">O</text><text x=\"80\" y=\"78\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F1\">F₁</text><text x=\"120\" y=\"102\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"lens\">P</text><text x=\"170\" y=\"78\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F2\">F₂</text><text x=\"222\" y=\"78\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"img\">I</text><text x=\"236\" y=\"122\" font-size=\"11\" class=\"t\" data-part=\"img\">(-y')</text><text x=\"56\" y=\"124\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"x1\">-x₁</text><text x=\"102\" y=\"124\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"f1\">-f₁</text><text x=\"148\" y=\"124\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"f2\">f₂</text><text x=\"196\" y=\"124\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"x2\">x₂</text></svg>"
            },
            {
              "type": "derivation",
              "label": "02 · §4.6 Derivation",
              "title": "The Newton formula",
              "legend": "Object height \\(y\\) at \\(x_1\\) from \\(F_1\\), image height \\(y'\\) at \\(x_2\\) from \\(F_2\\), focal lengths \\(f_1, f_2\\) (Fig. 4.8(a)).",
              "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Similar triangles at F1 and F2 for Newton lens formula\"><line x1=\"12\" y1=\"88\" x2=\"248\" y2=\"88\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><line x1=\"125\" y1=\"24\" x2=\"125\" y2=\"152\" class=\"lk\" stroke-width=\"2\" data-part=\"lens\"/><line x1=\"34\" y1=\"88\" x2=\"34\" y2=\"42\" class=\"lk\" stroke-width=\"2.5\" data-part=\"obj\"/><line x1=\"220\" y1=\"88\" x2=\"220\" y2=\"134\" class=\"lk\" stroke-width=\"2.5\" data-part=\"img\"/><polyline points=\"34,42 125,42 220,134\" class=\"lk\" stroke-width=\"1.8\" data-part=\"ray2\"/><polyline points=\"34,42 82,88 125,134 220,134\" class=\"hk\" stroke-width=\"2.4\" data-part=\"ray1\"/><path d=\"M 66 73 A 22 22 0 0 0 60 88\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F1\"/><path d=\"M 98 103 A 22 22 0 0 0 104 88\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F1\"/><path d=\"M 152 73 A 22 22 0 0 0 146 88\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F2\"/><path d=\"M 184 103 A 22 22 0 0 0 190 88\" class=\"lk\" stroke-width=\"1.8\" data-part=\"F2\"/><circle cx=\"82\" cy=\"88\" r=\"4\" class=\"h\" data-part=\"F1\"/><circle cx=\"168\" cy=\"88\" r=\"3.5\" class=\"f\" data-part=\"F2\"/><text x=\"24\" y=\"66\" font-size=\"11\" class=\"t\" data-part=\"obj\">y</text><text x=\"34\" y=\"104\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"obj\">O</text><text x=\"82\" y=\"80\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F1\">F₁</text><text x=\"125\" y=\"20\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"lens\">K</text><text x=\"118\" y=\"104\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"lens\">P</text><text x=\"125\" y=\"166\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"lens\">L</text><text x=\"168\" y=\"80\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"F2\">F₂</text><text x=\"220\" y=\"80\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"img\">I</text><text x=\"236\" y=\"118\" font-size=\"11\" class=\"t\" data-part=\"img\">(-y')</text><text x=\"58\" y=\"122\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"x1\">-x₁</text><text x=\"104\" y=\"122\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"f1\">-f₁</text><text x=\"146\" y=\"122\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"f2\">f₂</text><text x=\"194\" y=\"122\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"x2\">x₂</text></svg>",
              "phases": [
                {
                  "name": "First focus",
                  "why": "use similar triangles AOF₁ and LPF₁ at F₁"
                },
                {
                  "name": "Second focus",
                  "why": "use similar triangles KPF₂ and BIF₂ at F₂"
                },
                {
                  "name": "Equate ratios",
                  "why": "equate the two height ratios and cross-multiply"
                },
                {
                  "name": "Same medium",
                  "why": "set f₁ = -f and f₂ = f for the same surrounding medium"
                }
              ],
              "steps": [
                {
                  "phase": "First focus",
                  "focus": ["ray1", "obj", "lens", "F1", "x1", "f1"],
                  "tex": "\\frac{-y'}{y} = \\frac{-f_1}{-x_1}",
                  "note": "Similar right triangles \\(AOF_1\\) and \\(LPF_1\\) share the angle at \\(F_1\\) (Eq. 4.17)."
                },
                {
                  "focus": ["F1", "x1", "f1"],
                  "move": {
                    "type": "simplify"
                  },
                  "tex": "\\frac{-y'}{y} = \\frac{f_1}{x_1}",
                  "note": "Cancel the minus signs in the numerator and denominator on the right."
                },
                {
                  "phase": "Second focus",
                  "focus": ["ray2", "lens", "img", "F2", "f2", "x2"],
                  "move": {
                    "type": "rearrange",
                    "label": "Use similar triangles KPF₂ and BIF₂ (Eq. 4.18)"
                  },
                  "tex": "\\frac{-y'}{y} = \\frac{x_2}{f_2}",
                  "note": "In similar triangles \\(KPF_2\\) and \\(BIF_2\\) around \\(F_2\\), \\(-y'/y = x_2/f_2\\) (Eq. 4.18).",
                  "ask": {
                    "q": "In triangles \\(KPF_2\\) and \\(BIF_2\\), what does \\(-y' / y\\) equal?",
                    "options": [
                      "\\(x_2 / f_2\\)",
                      "\\(f_2 / x_2\\)",
                      "\\(x_1 / f_1\\)",
                      "\\(f_1 / f_2\\)"
                    ],
                    "answer": 0,
                    "why": "Since \\(KP = y\\) and \\(BI = -y'\\), the ratio of heights equals \\(x_2 / f_2\\)."
                  }
                },
                {
                  "phase": "Equate ratios",
                  "focus": ["F1", "F2", "x1", "f1", "f2", "x2"],
                  "move": {
                    "type": "substitute",
                    "by": "\\frac{-y'}{y} = \\frac{f_1}{x_1}"
                  },
                  "tex": "\\frac{f_1}{x_1} = \\frac{x_2}{f_2}",
                  "note": "Equate the two expressions for \\(-y'/y\\) from Eqs. (4.17) and (4.18)."
                },
                {
                  "focus": ["x1", "f1", "f2", "x2"],
                  "move": {
                    "type": "multiply",
                    "by": "x_1 f_2"
                  },
                  "tex": "f_1 f_2 = x_1 x_2",
                  "note": "Multiply both sides by \\(x_1 f_2\\) to get the Newtonian lens formula (Eq. 4.19).",
                  "ask": {
                    "q": "Which move clears both denominators in \\(f_1/x_1 = x_2/f_2\\)?",
                    "options": [
                      "Multiply both sides by \\(x_1 f_2\\)",
                      "Add \\(x_1 + f_2\\) to both sides",
                      "Divide both sides by \\(f_1\\)",
                      "Take the square root"
                    ],
                    "answer": 0,
                    "why": "Multiplying by \\(x_1 f_2\\) gives \\(f_1 f_2 = x_1 x_2\\)."
                  }
                },
                {
                  "phase": "Same medium",
                  "focus": ["f1", "f2", "x1", "x2"],
                  "move": {
                    "type": "substitute",
                    "by": "f_1 = -f,\\,f_2 = f"
                  },
                  "tex": "-f^2 = x_1 x_2",
                  "note": "When both sides have the same medium, Eq. (4.13) gives \\(f_1 = -f\\) and \\(f_2 = f\\).",
                  "ask": {
                    "q": "When the same medium surrounds the lens, what is \\(f_1 f_2\\)?",
                    "options": [
                      "\\(-f^2\\)",
                      "\\(+f^2\\)",
                      "\\(0\\)",
                      "\\(2f\\)"
                    ],
                    "answer": 0,
                    "why": "Because \\(f_1 = -f\\) and \\(f_2 = +f\\), their product is \\(-f^2\\)."
                  }
                },
                {
                  "focus": ["x1", "x2", "F1", "F2"],
                  "move": {
                    "type": "swap"
                  },
                  "tex": "x_1 x_2 = -f^2",
                  "note": "Thus \\(x_1\\) and \\(x_2\\) must always have opposite signs (Eq. 4.20).",
                  "ask": {
                    "q": "Since \\(x_1 x_2 = -f^2 < 0\\), what must be true of \\(x_1\\) and \\(x_2\\)?",
                    "options": [
                      "They have opposite signs",
                      "They are both positive",
                      "They are both negative",
                      "Their sum is zero"
                    ],
                    "answer": 0,
                    "why": "A negative product \\(-f^2\\) means one lies left of its focus and the other lies right."
                  }
                }
              ]
            },
            {
              "type": "intuition",
              "term": "lateral-magnification",
              "title": "How tall and which way up the image is",
              "meaning": "Lateral magnification compares the height of the image to the height of the object, including a sign for orientation.",
              "art": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Object height y and inverted image height y prime through lens center P\"><line x1=\"14\" y1=\"90\" x2=\"246\" y2=\"90\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 120 22 Q 108 90 120 158 Q 132 90 120 22\" class=\"s ok\" data-part=\"lens\"/><line x1=\"38\" y1=\"90\" x2=\"38\" y2=\"38\" class=\"lk\" stroke-width=\"2.6\" data-part=\"obj\"/><line x1=\"216\" y1=\"90\" x2=\"216\" y2=\"148\" class=\"lk\" stroke-width=\"2.6\" data-part=\"img\"/><line x1=\"38\" y1=\"38\" x2=\"216\" y2=\"148\" class=\"hk\" stroke-width=\"2.5\" data-part=\"ray3\"/><path d=\"M 95 75 A 28 28 0 0 0 92 90\" class=\"lk\" stroke-width=\"1.8\" data-part=\"theta\"/><path d=\"M 145 105 A 28 28 0 0 0 148 90\" class=\"lk\" stroke-width=\"1.8\" data-part=\"theta\"/><circle cx=\"120\" cy=\"90\" r=\"4\" class=\"h\" data-part=\"P\"/><text x=\"26\" y=\"66\" font-size=\"12\" class=\"t\" data-part=\"obj\">y</text><text x=\"38\" y=\"106\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"obj\">O</text><text x=\"84\" y=\"84\" font-size=\"11\" class=\"t\" data-part=\"theta\">θ</text><text x=\"154\" y=\"104\" font-size=\"11\" class=\"t\" data-part=\"theta\">θ</text><text x=\"116\" y=\"108\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"P\">P</text><text x=\"216\" y=\"82\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"img\">I</text><text x=\"232\" y=\"128\" font-size=\"12\" class=\"t\" data-part=\"img\">y'</text><text x=\"78\" y=\"136\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"u\">u &lt; 0</text><text x=\"170\" y=\"64\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"v\">v &gt; 0 (m = v/u)</text></svg>",
              "picture": "Look at the equal angle arcs θ at lens center P: similar right triangles give m = y'/y = v/u.",
              "example": "A positive magnification (m > 0) means an erect image; a negative magnification (m < 0) means an inverted image.",
              "bridge": "For a thin lens in one medium, similar triangles through pole P give m = y' / y = v / u = -f₁ / x₁ = -x₂ / f₂."
            },
            {
              "type": "info",
              "label": "03 · §4.7 Definition",
              "title": "What is lateral magnification?",
              "defines": ["lateral-magnification"],
              "body": "Lateral magnification m is the ratio of image height y' to object height y, where positive m means erect and negative m means inverted (Eq. 4.21).",
              "tex": "m = \\frac{y'}{y} = \\frac{v}{u} = -\\frac{f_1}{x_1} = -\\frac{x_2}{f_2}",
              "examples": [
                "m > 0: erect",
                "m < 0: inverted",
                "Two surfaces: m = m₁m₂"
              ]
            },
            {
              "type": "derivation",
              "label": "04 · §4.7 Derivation",
              "title": "Lateral magnification of spherical surface and thin lens",
              "legend": "Object \\(OA = y\\) at \\(u\\), center of curvature \\(C\\) at \\(R\\), image \\(IB = -y'\\) at \\(v\\) (Fig. 4.9, Eqs. 4.22–4.24).",
              "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Imaging an object of height y by a single spherical refracting surface\"><line x1=\"14\" y1=\"96\" x2=\"246\" y2=\"96\" class=\"lk\" stroke-width=\"2\" data-part=\"axis\"/><path d=\"M 110 22 Q 86 96 110 164\" class=\"lk\" stroke-width=\"2.5\" data-part=\"surf\"/><line x1=\"28\" y1=\"96\" x2=\"28\" y2=\"44\" class=\"lk\" stroke-width=\"2.5\" data-part=\"obj\"/><line x1=\"228\" y1=\"96\" x2=\"228\" y2=\"142\" class=\"lk\" stroke-width=\"2.5\" data-part=\"img\"/><line x1=\"28\" y1=\"44\" x2=\"228\" y2=\"142\" class=\"hk\" stroke-width=\"2.4\" data-part=\"rayC\"/><path d=\"M 130 86 A 26 26 0 0 0 128 96\" class=\"lk\" stroke-width=\"1.8\" data-part=\"C\"/><path d=\"M 178 106 A 26 26 0 0 0 180 96\" class=\"lk\" stroke-width=\"1.8\" data-part=\"C\"/><circle cx=\"98\" cy=\"96\" r=\"3.5\" class=\"f\" data-part=\"P\"/><circle cx=\"154\" cy=\"96\" r=\"4\" class=\"h\" data-part=\"C\"/><text x=\"28\" y=\"36\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"obj\">A (y)</text><text x=\"28\" y=\"112\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"obj\">O</text><text x=\"64\" y=\"132\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"u\">-u</text><text x=\"94\" y=\"112\" text-anchor=\"end\" font-size=\"11\" class=\"t\" data-part=\"P\">P</text><text x=\"126\" y=\"132\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"R\">R</text><text x=\"154\" y=\"84\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"C\">C</text><text x=\"190\" y=\"156\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"v\">v</text><text x=\"228\" y=\"88\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"img\">I</text><text x=\"228\" y=\"158\" text-anchor=\"middle\" font-size=\"11\" class=\"t\" data-part=\"img\">B (-y')</text></svg>",
              "phases": [
                {
                  "name": "Triangles at C",
                  "why": "use similar triangles AOC and ICB through center C"
                },
                {
                  "name": "Surface law",
                  "why": "substitute v/R and u/R from the Gaussian surface equation"
                },
                {
                  "name": "First lens surface",
                  "why": "write magnification m₁ for the first surface of a thin lens"
                },
                {
                  "name": "Second lens surface",
                  "why": "write magnification m₂ for the second surface of a thin lens"
                },
                {
                  "name": "Total magnification",
                  "why": "multiply m₁ and m₂ to get m = v/u"
                }
              ],
              "steps": [
                {
                  "phase": "Triangles at C",
                  "focus": ["rayC", "obj", "img", "C"],
                  "tex": "\\frac{-y'}{y} = \\frac{v - R}{-u + R}",
                  "note": "Ray \\(ACB\\) along the normal at \\(C\\) passes undeviated, giving similar triangles \\(AOC\\) and \\(ICB\\) (Eq. 4.22)."
                },
                {
                  "focus": ["R", "u", "v", "C"],
                  "move": {
                    "type": "divide",
                    "by": "R",
                    "label": "Divide numerator and denominator by R"
                  },
                  "tex": "\\frac{-y'}{y} = \\frac{\\frac{v}{R} - 1}{-\\frac{u}{R} + 1}",
                  "note": "Divide numerator and denominator on the right-hand side by \\(R\\) (Eq. 4.22).",
                  "ask": {
                    "q": "Why does the ray from \\(A\\) through \\(C\\) pass straight without bending?",
                    "options": [
                      "It hits the spherical surface along the normal",
                      "Refractive indices \\(n_1\\) and \\(n_2\\) are equal",
                      "The surface is flat at \\(C\\)",
                      "It reflects back to \\(O\\)"
                    ],
                    "answer": 0,
                    "why": "Any line through center of curvature \\(C\\) is normal to the sphere, so \\(\\phi_1 = \\phi_2 = 0\\)."
                  }
                },
                {
                  "phase": "Surface law",
                  "focus": ["surf", "u", "v", "R"],
                  "move": {
                    "type": "substitute",
                    "by": "\\frac{n_2}{v} - \\frac{n_1}{u} = \\frac{n_2 - n_1}{R}"
                  },
                  "tex": "\\frac{-y'}{y} = -\\frac{n_1 v}{n_2 u}",
                  "note": "Substitute \\(v/R - 1\\) and \\(-u/R + 1\\) from Eq. (4.5)."
                },
                {
                  "focus": ["obj", "img", "u", "v"],
                  "move": {
                    "type": "negate"
                  },
                  "tex": "m = \\frac{n_1 v}{n_2 u}",
                  "note": "Negate both sides and set \\(m = y'/y\\) for a single refracting surface (Eq. 4.23).",
                  "ask": {
                    "q": "What is the lateral magnification of a single surface from \\(n_1\\) to \\(n_2\\)?",
                    "options": [
                      "\\(n_1 v / (n_2 u)\\)",
                      "\\(n_2 v / (n_1 u)\\)",
                      "\\(v / u\\)",
                      "\\(-u / v\\)"
                    ],
                    "answer": 0,
                    "why": "Refraction from \\(n_1\\) into \\(n_2\\) gives \\(m = (n_1 v)/(n_2 u)\\) (Eq. 4.23)."
                  }
                },
                {
                  "phase": "First lens surface",
                  "focus": ["surf", "u", "v"],
                  "move": {
                    "type": "evaluate",
                    "by": "v \\to v'"
                  },
                  "tex": "m_1 = \\frac{n_1 v'}{n_2 u}",
                  "note": "For the first surface of a thin lens (\\(n_1 \\to n_2\\)), intermediate image at \\(v'\\) has magnification \\(m_1\\)."
                },
                {
                  "phase": "Second lens surface",
                  "focus": ["surf", "v"],
                  "move": {
                    "type": "rearrange",
                    "label": "Write second surface magnification m₂"
                  },
                  "tex": "m_2 = \\frac{n_2 v}{n_1 v'}",
                  "note": "For the second surface (\\(n_2 \\to n_1\\)), object at \\(v'\\) forms image at \\(v\\) with magnification \\(m_2\\).",
                  "ask": {
                    "q": "How is total magnification \\(m\\) found for two surfaces in succession?",
                    "options": [
                      "Multiply \\(m_1\\) by \\(m_2\\)",
                      "Add \\(m_1\\) and \\(m_2\\)",
                      "Subtract \\(m_2\\) from \\(m_1\\)",
                      "Divide \\(m_1\\) by \\(v'\\)"
                    ],
                    "answer": 0,
                    "why": "The first image height is scaled again by \\(m_2\\), so total magnification is \\(m_1 m_2\\)."
                  }
                },
                {
                  "phase": "Total magnification",
                  "focus": ["obj", "img", "u", "v"],
                  "move": {
                    "type": "multiply",
                    "by": "m_1"
                  },
                  "tex": "m_1 m_2 = \\frac{n_1 v'}{n_2 u}\\cdot\\frac{n_2 v}{n_1 v'}",
                  "note": "Multiply the two surface magnifications \\(m_1\\) and \\(m_2\\) together."
                },
                {
                  "focus": ["obj", "img", "u", "v"],
                  "move": {
                    "type": "cancel"
                  },
                  "tex": "m = \\frac{v}{u}",
                  "note": "Cancel \\(n_1, n_2\\) and \\(v'\\) to get \\(m = m_1 m_2 = v/u\\) (Eq. 4.24).",
                  "ask": {
                    "q": "Which factors cancel when \\(m_1\\) and \\(m_2\\) are multiplied?",
                    "options": [
                      "\\(n_1, n_2\\) and \\(v'\\)",
                      "\\(u\\) and \\(v\\)",
                      "Only \\(u\\)",
                      "Only \\(n_1\\)"
                    ],
                    "answer": 0,
                    "why": "Factors \\(n_1, n_2\\) and intermediate image distance \\(v'\\) cancel, leaving \\(m = v/u\\)."
                  }
                }
              ]
            },
            {
              "type": "math",
              "label": "05 · §4.7 Example",
              "title": "Two thin lenses separated by 8 cm (Example 4.3)",
              "tex": "v_1 = +40\\text{ cm},\\; u_2 = +32\\text{ cm} \\implies \\frac{1}{v_2} = \\frac{1}{32} - \\frac{1}{10} = -\\frac{22}{320}",
              "body": "Convex lens (\\(f = +20\\text{ cm}\\)) with \\(u = -40\\text{ cm}\\) gives \\(v_1 = +40\\text{ cm}, m_1 = -1\\). Concave lens (\\(f = -10\\text{ cm}\\)) 8 cm behind has virtual object \\(u_2 = +32\\text{ cm}\\), giving \\(v \\approx -14.5\\text{ cm}\\)."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "What is Newton's lens formula when the same medium is on both sides?",
              "options": [
                "\\(x_1 x_2 = -f^2\\)",
                "\\(x_1 x_2 = +f^2\\)",
                "\\(x_1 + x_2 = f\\)",
                "\\(x_1 / x_2 = -f\\)"
              ],
              "answer": 0,
              "why": "With the same medium on both sides, \\(f_1 = -f\\) and \\(f_2 = f\\), so \\(x_1 x_2 = f_1 f_2 = -f^2\\)."
            },
            {
              "type": "mcq",
              "label": "Quiz · OMR",
              "time": 45,
              "q": "What does a negative lateral magnification \\(m < 0\\) indicate?",
              "options": [
                "The image is inverted",
                "The image is erect",
                "The lens must be diverging",
                "No image is formed"
              ],
              "answer": 0,
              "why": "Since \\(m = y'/y\\), a negative value means \\(y'\\) and \\(y\\) have opposite signs (inverted)."
            },
            {
              "type": "number",
              "label": "Quiz · Number",
              "time": 60,
              "q": "A thin lens in air has \\(f = 10\\text{ cm}\\) and \\(x_1 = -20\\text{ cm}\\). Find \\(x_2\\).",
              "answer": 5,
              "tolerance": 0.05,
              "unit": "cm",
              "why": "From \\(x_1 x_2 = -f^2\\), \\(x_2 = -100 / (-20) = +5\\text{ cm}\\)."
            },
            {
              "type": "number",
              "label": "Quiz · Number",
              "time": 60,
              "q": "For a thin lens with \\(u = -40\\text{ cm}\\) and \\(v = +40\\text{ cm}\\), find \\(m\\).",
              "answer": -1,
              "tolerance": 0.01,
              "unit": "",
              "why": "Lateral magnification \\(m = v / u = (+40) / (-40) = -1\\)."
            }
          ]
        }
      ]
    }
  ]
}
```

---

### 2. Unified Diff (`changes.diff`)

```diff
--- a/skills/01-schema.md
+++ b/skills/01-schema.md
@@ -175,11 +175,16 @@
 ### `derivation` — a derived result on a single flip card
 See `02-derivations.md`. Shape:
 ```json
 { "type": "derivation", "title": "Bond energy, step by step",
   "legend": "\\(k\\) Coulomb constant, \\(r\\) separation.",
-  "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"...\">...</svg>",
+  "setup": "<svg viewBox=\"0 0 260 180\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"...\"><line x1=\"...\" y1=\"...\" x2=\"...\" y2=\"...\" class=\"lk\" data-part=\"sep\"/></svg>",
   "phases": [ { "name": "Model", "why": "energy = attraction + repulsion" } ],
-  "steps": [ { "tex": "...", "phase": "Model", "note": "..." },
-             { "tex": "...", "move": { "type": "differentiate", "wrt": "r" }, "note": "...", "ask": { ... } } ] }
+  "steps": [ { "tex": "...", "phase": "Model", "focus": ["sep"], "note": "..." },
+             { "tex": "...", "move": { "type": "differentiate", "wrt": "r" }, "focus": ["sep"], "note": "...", "ask": { ... } } ] }
 ```
+- Give each highlightable ray, side, angle arc or label in `setup` a `data-part="name"` attribute.
+- Each step lists the parts it uses in `"focus": ["name1", "name2"]` so the diagram highlights them at the same time.
+- Write parallel steps (such as two surfaces of a lens) one after the other as separate steps with their own phase labels, never side by side.
+- An **All steps** summary view lists every step in order (step number, equation and move) after the final step and via the top button.
 
 ### `mcq` — multiple choice
--- a/skills/02-derivations.md
+++ b/skills/02-derivations.md
@@ -14,14 +14,19 @@
 4. Write the *result* of the move in `tex`, already simplified. Do **not** write the
    intermediate "both sides" line; the app draws that for you.
-5. 4–12 steps. The first step has no `move`. Every later step has one.
+5. 4–12 detailed steps: include every algebra move, every approximation, and every sign
+   decision a Year 2 student needs. When two things happen in parallel (e.g. refraction at
+   surface 1 and surface 2 of a thin lens), write them one after the other as separate steps,
+   each with its own phase label—never side by side. The first step has no `move`; every later step has one.
 6. Every step has a `note`: one short sentence saying *why* or what just cancelled (≤ 120 chars).
 7. Include a `"setup"` SVG (following `03-svg-art.md`) showing the geometry or circuit used by
-   the derivation. It is drawn on the board beside the equations, and the part used in the
-   active step is highlighted.
+   the derivation, with `data-part="name"` on each highlightable ray, side, angle arc and label.
+   Each step names the parts it uses in `"focus": ["name1", "name2"]` so the picture highlights
+   those lines at the same time.
 8. Mark 3–6 phases with `"phase"` on the step where each phase starts. List the same phases in
-   `"phases"` with a one-line `why` each. Do not create separate route, step, or full-page cards.
+   `"phases"` with a one-line `why` each. Do not create separate route, step, or full-page cards;
+   the card includes an **All steps** summary stage that opens after the last step or from the top button.
 9. Put **4** `ask` checkpoints on steps where the next move is a real decision, an identity
    or a physical law is used. Ask **only about the next step** (what the next line is, or why
    the next line is true; never ask about steps far away). Keep the question to one short line
    (≤ 15 words) and each option to at most 6 words.
--- a/skills/03-svg-art.md
+++ b/skills/03-svg-art.md
@@ -26,7 +26,9 @@
 
 - Set line thickness with `stroke-width="2"` (allowed). Dashes with `stroke-dasharray="5 5"` (allowed).
 - **Angle arcs**: whenever an angle (such as θ, φ, α, β, i or r) is shown or used, draw its curved mark as a `<path d="M x1 y1 A r r 0 0 1 x2 y2" class="lk" stroke-width="1.8"/>` (line, no fill), placed **after** the lines/rays it marks so it stays visible on top.
+- **Highlightable parts (`data-part`)**: give each ray, triangle side, surface, angle arc and matching label a `data-part="name"` attribute so derivation steps can highlight them via `"focus": ["name"]`.
+- **Palette tokens only**: never hard-code hex/rgb colours in SVGs or maths CSS; use only the allowed classes and the tokens from `01-tokens.css`.
 - Text: `font-size` 11–26, `text-anchor="middle"` to centre. Max ~4 words per label.
 - Only **one** amber (`h`/`hk`) highlight per picture: it is where the eye goes.
 - Inside the JSON string, every `"` in the SVG must be written `\"`.
--- a/skills/04-questions.md
+++ b/skills/04-questions.md
@@ -28,4 +28,5 @@
 - For general syllabus topics: 3–5 questions at the end, mixing types: at least one `mcq`, and one `fill` or
   `number` when the topic has a key word or a calculation.
 - In a `derivation`, 4 `ask` checkpoints asking **only about the next step** (what the next line is, or why it is true).
+  Each checkpoint question is one line (≤ 15 words) and each option is at most 6 words, matching the detailed step sequence.
 
--- a/skills/05-checklist.md
+++ b/skills/05-checklist.md
@@ -78,9 +78,12 @@
 ## Physics content
 - [ ] Every topic is checked against the syllabus item (and nothing outside the timetable list is added).
+- [ ] Symbols, signs, equations and section names match the textbook (Ghatak, *Optics*), with `source` on every sheet.
 - [ ] Every circuit has a circuit diagram card; every optics experiment has a set-up diagram and a graph.
 - [ ] Keep syllabus topics compact; retain a full model-paper question and rubric in the same sheet even when that exceeds 14 cards.
 
 ## SVG
 - [ ] `viewBox="0 0 260 180"`, only allowed classes, no colours, one amber highlight.
+- [ ] Highlightable lines, arcs and labels have `data-part="name"`, and derivation steps name them in `focus`.
+- [ ] Maths and derivation styles use only the colour tokens from `01-tokens.css` (no hard-coded red or rose).
 
 When I run `python build.py`, it prints every problem with its exact location
--- a/study-match/src/components/02-mathflow.js
+++ b/study-match/src/components/02-mathflow.js
@@ -122,6 +122,7 @@
   function mount(root, spec) {
     var stage = root.querySelector('.mf-stage'), board = root.querySelector('.mf-board');
     var setupEl = root.querySelector('.mf-setup');
+    var summaryEl = root.querySelector('.mf-summary'), sumBtn = root.querySelector('[data-mf="summary"]');
     var noteEl = root.querySelector('.mf-note'), dotsEl = root.querySelector('.mf-dots');
     var phEl = root.querySelector('.mf-phases'), countEl = root.querySelector('.mf-count');
     var playBtn = root.querySelector('[data-mf="play"]');
@@ -152,6 +153,16 @@
     dotsEl.innerHTML = frames.map(function (f, j) {
       return '<button type="button" class="mf-dot' + (f.ask ? ' is-ask' : '') + '" aria-label="Step ' + (j + 1) + '" data-j="' + j + '"></button>';
     }).join('');
+    if (summaryEl) {
+      summaryEl.innerHTML = '<div class="mf-sum-list">' + spec.steps.map(function (st, idx) {
+        var mvText = st.move ? T.label(st.move) : (st.phase || 'Start');
+        return '<div class="mf-sum-row"><span class="mf-sum-num">' + SM.pad2(idx + 1) + '</span>' +
+          '<span class="mf-sum-eq">\\(' + st.tex + '\\)</span>' +
+          '<span class="mf-sum-mv">' + SM.mathLabel(SM.esc(mvText)) + '</span></div>';
+      }).join('') + '</div>';
+      SM.mathReady(function (ok) { if (ok) SM.typeset(summaryEl); });
+    }
 
     function chrome(i) {
       var cur = frames[i] ? phases.indexOf(frames[i].phase) : -1;
@@ -169,7 +180,14 @@
       Array.prototype.forEach.call(svg.querySelectorAll('.mf-part-on'), function (el) { el.classList.remove('mf-part-on'); });
       if (!f) return;
       var st = spec.steps[f.si] || {};
-      var hay = (f.tex || '') + ' ' + (st.note || '') + ' ' + (st.focus || '');
+      var focusList = Array.isArray(st.focus) ? st.focus : (st.focus ? String(st.focus).split(/[\s,]+/) : []);
+      var focusSet = {};
+      focusList.forEach(function (k) { if (k) focusSet[k] = 1; });
+      var hay = (f.tex || '') + ' ' + (st.note || '') + ' ' + focusList.join(' ');
+      Array.prototype.forEach.call(svg.querySelectorAll('[data-part]'), function (el) {
+        var dp = el.getAttribute('data-part') || '';
+        if (focusSet[dp] || (!focusList.length && dp && hay.indexOf(dp) !== -1)) el.classList.add('mf-part-on');
+      });
       var map = {
         '\\theta_1': 'θ₁', '\\theta_2': 'θ₂', '\\phi_1': 'φ₁', '\\phi_2': 'φ₂',
         '\\alpha_1': 'α₁', '\\alpha_2': 'α₂', '\\beta': 'β',
@@ -198,9 +216,6 @@
         var near = hitTexts.some(function (pt) { return Math.hypot(pt.x - px, pt.y - py) < 38; });
         if (near) p.classList.add('mf-part-on');
       });
-      Array.prototype.forEach.call(svg.querySelectorAll('[data-part]'), function (el) {
-        if (hay.indexOf(el.getAttribute('data-part')) !== -1) el.classList.add('mf-part-on');
-      });
     }
 
     function setNote(html) {
@@ -391,7 +406,11 @@
       setNote(B.note);
       highlightSetup(B);
       chrome(i);
-      if (i === frames.length - 1) complete();
+      if (i === frames.length - 1) {
+        complete();
+        if (summaryEl && !instant) later.push(setTimeout(function () { api.toggleSummary(true); }, 1350));
+      } else if (summaryEl && !summaryEl.hidden) api.toggleSummary(false);
     }
 
     function complete() {
@@ -478,9 +497,18 @@
     };
     api.isAsking = function () { return asking >= 0; };
+    api.toggleSummary = function (force) {
+      if (!summaryEl) return;
+      var showSum = force === undefined ? summaryEl.hidden : !!force;
+      summaryEl.hidden = !showSum;
+      stage.hidden = showSum;
+      if (sumBtn) sumBtn.classList.toggle('is-on', showSum);
+    };
     api.practise = function () {
       if (SM.isPaused && SM.isPaused()) return;
+      api.toggleSummary(false);
       asking = -1; askEl.hidden = true; panel.hidden = false;
       Object.keys(answered).forEach(function (k) { delete answered[k]; });
       stopPlay(); reset(); api.play();
     };
     api.isPlaying = function () { return playing; };
     api.pause = stopPlay;
@@ -490,9 +518,10 @@
         e.stopPropagation();
         var a = b.getAttribute('data-mf');
         if (a === 'practise') api.practise();
+        else if (a === 'summary') api.toggleSummary();
         else if (a === 'flip-back') api.flip(false);
         else if (a === 'flip-open') api.flip(true);
-        else if (a === 'replay') api.replay();
-        else if (a === 'next') api.next();
-        else if (a === 'prev') api.prev();
-        else if (a === 'play') api.toggle();
+        else if (a === 'replay') { api.toggleSummary(false); api.replay(); }
+        else if (a === 'next') { api.toggleSummary(false); api.next(); }
+        else if (a === 'prev') { api.toggleSummary(false); api.prev(); }
+        else if (a === 'play') { api.toggleSummary(false); api.toggle(); }
       });
     });
@@ -518,6 +547,7 @@
       var d = e.target.closest('.mf-dot');
       if (!d) return;
       e.stopPropagation();
+      api.toggleSummary(false);
       api.jump(Number(d.dataset.j));
     });
 
--- a/study-match/src/components/03-render.js
+++ b/study-match/src/components/03-render.js
@@ -149,19 +149,21 @@
           '</div></div>' +
           '<div class="mf-face mf-back" inert>' +
           '<div class="mf-top"><span class="card-index">' + esc(c.label || 'Derivation') + '</span>' +
-          '<div class="mf-top-actions"><span class="mf-count"></span><button type="button" class="chip" data-mf="flip-back">Concept</button></div></div>' +
+          '<div class="mf-top-actions"><span class="mf-count"></span><button type="button" class="chip" data-mf="summary">All steps</button><button type="button" class="chip" data-mf="flip-back">Concept</button></div></div>' +
           '<h2 class="card-title mf-back-title">' + (c.title || 'Step-by-step derivation') + '</h2>' +
           '<div class="mf-phases"></div>' +
-          '<div class="mf-board' + (setupSVG ? ' has-setup' : '') + '">' +
+          '<div class="mf-work' + (setupSVG ? ' has-setup' : '') + '">' +
           (setupSVG ? '<div class="mf-setup art">' + setupSVG + '</div>' : '') +
-          '<div class="mf-stage"></div></div>' +
+          '<div class="mf-right">' +
+          '<div class="mf-board"><div class="mf-stage"></div><div class="mf-summary scroll-y" hidden></div></div>' +
           '<div class="mf-panel"><p class="mf-note">Press play. It stops at each decision so you can call the next move.</p><div class="mf-dots"></div>' +
           '<div class="mf-ctrl"><button type="button" class="chip" data-mf="prev" aria-label="Previous step">&#9664;</button>' +
           '<button type="button" class="chip mf-play" data-mf="play" aria-label="Play or pause">&#9654;</button>' +
           '<button type="button" class="chip" data-mf="next" aria-label="Next step">&#9654;&#9654;</button>' +
           '<button type="button" class="chip" data-mf="replay" aria-label="Replay from start">&#8634;</button>' +
           '<button type="button" class="chip mf-practise" data-mf="practise">Practise again</button></div></div>' +
           '<div class="mf-ask" hidden><span class="mf-ask-tag">Your move</span><p class="mf-ask-q"></p><div class="mf-ask-opts"></div>' +
-          '<p class="mf-ask-why" hidden></p><button type="button" class="btn amber mf-ask-go" hidden>Continue &#9654;</button></div></div></div></article>';
+          '<p class="mf-ask-why" hidden></p><button type="button" class="btn amber mf-ask-go" hidden>Continue &#9654;</button></div></div></div></div></div></article>';
       case 'page':
         return '<article class="card"' + a + '><span class="card-index">One page</span><h2 class="card-title">' + c.title + '</h2>' +
--- a/study-match/src/components/04-shelf.js
+++ b/study-match/src/components/04-shelf.js
@@ -144,7 +144,7 @@
     shelf.addEventListener('wheel', function (e) {
       if (e.ctrlKey || !SM.$('mc').hidden) return;
       var vertical = Math.abs(e.deltaY) > Math.abs(e.deltaX);
-      var sc = e.target.closest('.scroll-y, .omr-content, .eval-content, .mf-ask, textarea, .has-text-answer');
+      var sc = e.target.closest('.scroll-y, .mf-summary, .omr-content, .eval-content, .mf-ask, textarea, .has-text-answer');
       if (sc && vertical && sc.scrollHeight > sc.clientHeight + 2) return;
       var hsc = e.target.closest('.mf-board');
       if (hsc && !vertical && hsc.scrollWidth > hsc.clientWidth + 2) return;
--- a/study-match/src/styles/07-mathflow.css
+++ b/study-match/src/styles/07-mathflow.css
@@ -1,19 +1,4 @@
 /* MathFlow player card */
-:root {
-  --mf-given: var(--ink);
-  --mf-step: #b45309;
-  --mf-cancel: #be123c;
-  --mf-result: #0369a1;
-  --mf-result-bg: rgba(3, 105, 161, 0.14);
-}
-[data-theme="dark"] {
-  --mf-given: #f1f5f9;
-  --mf-step: #fbbf24;
-  --mf-cancel: #fb7185;
-  --mf-result: #38bdf8;
-  --mf-result-bg: rgba(56, 189, 248, 0.18);
-}
 .card.mf-card:not(.mf-flip-card) { padding: 14px 12px; gap: 9px; }
 .mf-top { display: flex; justify-content: space-between; align-items: center; gap: 6px; }
 .mf-top-actions { display: flex; align-items: center; gap: 6px; }
@@ -22,33 +7,42 @@
 .mf-phases { display: flex; gap: 5px; overflow-x: auto; scrollbar-width: none; flex: 0 0 auto; }
 .mf-phases::-webkit-scrollbar { display: none; }
 .mf-ph { flex: 0 0 auto; font-size: 10.5px; font-weight: 700; padding: 4px 8px; border-radius: 999px; background: var(--lav); color: var(--muted); transition: background 0.3s, color 0.3s; }
-.mf-ph.is-past { color: var(--mf-result); box-shadow: inset 0 0 0 1px var(--mf-result); }
+.mf-ph.is-past { color: var(--sage); box-shadow: inset 0 0 0 1px var(--sage); }
 .mf-ph.is-now { background: var(--violet); color: var(--on-violet); }
+.mf-work { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; gap: 6px; }
+.mf-right { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; gap: 6px; }
 .mf-board {
-  flex: 1 1 auto; min-height: 110px; display: flex; flex-direction: column; justify-content: flex-start;
+  flex: 1 1 auto; min-height: 76px; display: flex; flex-direction: column; justify-content: flex-start;
   border-radius: 16px; background-color: var(--lav);
   background-image: linear-gradient(var(--grid) 1px, transparent 1px), linear-gradient(90deg, var(--grid) 1px, transparent 1px);
   background-size: 16px 16px; padding: 4px; gap: 4px; position: relative;
   overflow-x: auto; overflow-y: hidden; -webkit-overflow-scrolling: touch;
 }
-.mf-board.has-setup { min-height: 60%; }
 .mf-setup {
-  width: 100%; flex: 1 0 calc((var(--sheet-h, 620px) - 22px) * 0.46);
+  width: 100%; flex: 0 0 calc((var(--sheet-h, 620px) - 22px) * 0.46);
   min-height: calc((var(--sheet-h, 620px) - 22px) * 0.45);
   padding: 4px; border-radius: 12px; background: var(--card);
 }
 .mf-setup > svg { width: 100%; height: 100%; max-height: 100%; }
-.mf-setup svg text.mf-part-on { fill: var(--mf-step) !important; font-weight: 800; text-decoration: underline; }
+.mf-setup svg text.mf-part-on { fill: var(--hl) !important; font-weight: 800; text-decoration: underline; }
 .mf-setup svg path.mf-part-on,
 .mf-setup svg line.mf-part-on,
-.mf-setup svg polyline.mf-part-on { stroke: var(--mf-step) !important; stroke-width: 2.8 !important; fill: none !important; }
+.mf-setup svg polyline.mf-part-on { stroke: var(--hl) !important; stroke-width: 2.8 !important; fill: none !important; }
+.mf-setup svg circle.mf-part-on,
+.mf-setup svg polygon.mf-part-on,
+.mf-setup svg rect.mf-part-on { stroke: var(--hl) !important; stroke-width: 2.4 !important; }
 .mf-stage { position: relative; width: 100%; flex: 0 0 auto; user-select: none; }
-.mf-sp { position: absolute; left: 0; top: 0; overflow: visible; color: var(--mf-given); transform-origin: 2px 2px; transition: color 0.6s ease; will-change: transform, opacity; }
+.mf-stage[hidden], .mf-summary[hidden] { display: none; }
+.mf-summary { width: 100%; height: 100%; overflow-y: auto; padding: 6px; }
+.mf-sum-list { display: flex; flex-direction: column; gap: 6px; }
+.mf-sum-row { display: grid; grid-template-columns: 24px minmax(0, 1fr) auto; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 10px; background: var(--card); font-size: 12px; }
+.mf-sum-num { font-size: 10px; font-weight: 800; color: var(--violet); background: var(--lav); border-radius: 999px; padding: 2px 6px; text-align: center; }
+.mf-sum-eq { overflow-x: auto; color: var(--ink); font-weight: 600; }
+.mf-sum-mv { font-size: 11px; font-weight: 700; color: var(--hl); text-align: right; }
+.mf-sp { position: absolute; left: 0; top: 0; overflow: visible; color: var(--ink); transform-origin: 2px 2px; transition: color 0.6s ease; will-change: transform, opacity; }
 .mf-sp path, .mf-sp rect { fill: currentColor; stroke: none; }
-.mf-sp.is-new, .mf-sp.is-op { color: var(--mf-step); }
-.mf-sp.is-out { color: var(--mf-cancel); }
+.mf-sp.is-new, .mf-sp.is-op { color: var(--hl); }
+.mf-sp.is-out { color: var(--muted); }
 .mf-ghost { position: absolute; left: 0; top: 0; color: var(--ink-2); transform-origin: 0 0; white-space: nowrap;
   transition: transform 0.75s cubic-bezier(0.65, 0, 0.35, 1), opacity 0.75s ease; }
 .mf-ghost svg { display: block; }
-.mf-strike { position: absolute; left: 0; top: 0; height: 2.5px; border-radius: 2px; background: var(--mf-cancel); transform-origin: 0 50%; }
+.mf-strike { position: absolute; left: 0; top: 0; height: 2.5px; border-radius: 2px; background: var(--muted); transform-origin: 0 50%; }
 .mf-box { position: absolute; left: 0; top: 0; overflow: visible; }
-.mf-box rect { fill: none; stroke: var(--mf-result); stroke-width: 2.4; }
+.mf-box rect { fill: none; stroke: var(--violet); stroke-width: 2.4; }
 .mf-err { position: absolute; left: 6px; right: 6px; font: 600 11px/1.4 ui-monospace, Menlo, monospace; color: var(--coral); background: var(--coral-bg); border-radius: 8px; padding: 6px 8px; white-space: pre-wrap; word-break: break-all; }
 .mf-note { font-size: 12px; line-height: 1.32; font-weight: 600; color: var(--ink-2); min-height: 26px; transition: opacity 0.2s ease; }
 .mf-note b { color: var(--ink); }
@@ -59,15 +53,15 @@
 .mf-ctrl { display: flex; gap: 5px; align-items: center; flex-wrap: wrap; }
 .mf-ctrl .chip { min-width: 34px; text-align: center; padding: 5px 8px; }
 .mf-ctrl .mf-play { background: var(--violet); color: var(--on-violet); }
-.mf-practise { display: none; margin-left: auto; background: var(--mf-result-bg); color: var(--mf-result); }
+.mf-practise { display: none; margin-left: auto; background: var(--lav-2); color: var(--violet); }
 .card.mf-card.is-completed .mf-practise { display: inline-block; }
 .mf-panel, .mf-ask { display: flex; flex-direction: column; gap: 5px; flex: 0 0 auto; }
 .mf-ask[hidden], .mf-panel[hidden] { display: none; }
 .mf-ask-tag { align-self: flex-start; font-size: 10px; font-weight: 800; letter-spacing: 0.07em; text-transform: uppercase; background: var(--amber-bg); color: var(--hl); border-radius: 999px; padding: 3px 8px; }
 .mf-ask-q { font-size: 12.5px; font-weight: 700; line-height: 1.28; }
 .mf-ask-opts { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
 .mf-ask-opts button { appearance: none; border: 0; cursor: pointer; background: var(--lav); color: var(--ink); border-radius: 10px; padding: 6px 8px; font-size: 11.5px; font-weight: 600; text-align: left; line-height: 1.22; overflow-wrap: anywhere; }
-.mf-ask-opts button.is-correct { background: var(--mf-result-bg); box-shadow: inset 0 0 0 2px var(--mf-result); }
-.mf-ask-opts button.is-wrong { background: var(--coral-bg); box-shadow: inset 0 0 0 2px var(--mf-cancel); text-decoration: line-through; }
+.mf-ask-opts button.is-correct { background: var(--sage-bg); box-shadow: inset 0 0 0 2px var(--sage); }
+.mf-ask-opts button.is-wrong { background: var(--coral-bg); box-shadow: inset 0 0 0 2px var(--coral); text-decoration: line-through; }
 .mf-ask-why { font-size: 12px; line-height: 1.32; color: var(--ink-2); font-weight: 600; }
 .mf-ask-why[hidden], .mf-ask-go[hidden] { display: none; }
--- a/study-match/src/styles/09-desktop.css
+++ b/study-match/src/styles/09-desktop.css
@@ -34,8 +34,17 @@
   .omr-option { font-size: 15px; padding: 12px 14px; }
   .math { font-size: 17px; }
   .sheet.is-open .card:not(.is-focus) { opacity: 0.38; transform: scale(0.97); }
-  .card.mf-card { padding: 18px 16px; }
+  .sheet.is-open, .sheet.is-open .pages { width: max-content; }
+  .card.mf-card { flex: 0 0 clamp(680px, 64vw, 860px); width: clamp(680px, 64vw, 860px); }
+  .card.mf-card:not(.mf-flip-card), .card.mf-flip-card .mf-face { padding: 18px 16px; gap: 10px; }
+  .mf-front { display: grid; grid-template-columns: minmax(250px, 44%) minmax(0, 1fr); grid-template-rows: auto auto 1fr; column-gap: 16px; row-gap: 10px; }
+  .mf-front .mf-top, .mf-front .card-title { grid-column: 1 / -1; }
+  .mf-front-art { height: 100%; min-height: 0; flex: initial; }
+  .mf-work.has-setup { display: grid; grid-template-columns: minmax(260px, 44%) minmax(0, 1fr); gap: 16px; align-items: stretch; }
+  .mf-work.has-setup .mf-setup { height: 100%; min-height: 0; flex: initial; }
+  .mf-right { height: 100%; min-width: 0; gap: 10px; }
   .mf-card { --mf-size: 23px; }
+  .mf-sum-row { font-size: 14px; padding: 8px 10px; }
   .mf-note { font-size: 14.5px; }
   .mf-ask-q { font-size: 16px; }
   .mf-ask-opts button { font-size: 14px; padding: 10px 11px; }
```

---

### 3. Short Notes

#### What was changed
1. **Change 1 (`data-part` and `focus` line highlighting):**
   - Added `data-part="name"` attributes to the highlightable rays, triangle sides, surfaces, angle arcs, and labels in every SVG in `study-match/data/data.json`.
   - Added a `"focus": [...]` array on every derivation step in `data.json` naming the exact diagram parts used in that step.
   - Updated `highlightSetup(f)` in `02-mathflow.js` to highlight every `[data-part]` element listed in `st.focus` (including lines, polylines, arcs, and labels) at the same time as the step plays.
2. **Change 2 (App colour palette only):**
   - Removed all hard-coded colour variables (`--mf-step`, `--mf-cancel`, `--mf-result`, `--mf-result-bg`) from `07-mathflow.css`.
   - Styled all derivation elements exclusively with tokens from `01-tokens.css`: `--ink` for given terms, `--hl` (amber) for the active step and highlighted diagram parts, `--muted` with a strike line for cancelled terms (no red or rose in maths), `--violet` for the final boxed result, `--sage` for completed phases and right checkpoint answers, and `--coral` only in quiz wrong-answer feedback.
3. **Change 3 (Detailed steps, and parallel steps one after another):**
   - Expanded all 6 derivations in `data.json` so every algebra move, paraxial approximation, and Cartesian sign substitution has its own step.
   - Wrote parallel operations (triangle $AMR$ then triangle $RBN$ in Unit 1; incident ray then refracted/reflected ray in Unit 2; first lens surface Eq. 4.8 then second lens surface Eq. 4.9 in Unit 3; first focus $F_1$ then second focus $F_2$, and $m_1$ then $m_2$ in Unit 4) one after the other as separate steps with their own phase labels.
4. **Change 4 (Desktop wide layout and derivation summary):**
   - Added `.mf-work` and `.mf-right` in `03-render.js`, `07-mathflow.css`, and `09-desktop.css`. On phones (`< 900px`), the setup diagram stays on top and the equations below; on desktop (`>= 900px`), the derivation card widens (`clamp(680px, 64vw, 860px)`) with the setup diagram on the **left** and the equations, step note, and question area on the **right**.
   - Added an **All steps** summary stage (`.mf-summary`) that lists every step in order (step number, equation, and move), opens automatically after the last step completes, and can be toggled at any time from the `All steps` button in `.mf-top-actions`.
5. **Change 5 (Textbook consistency):**
   - Checked all symbols, signs, equation numbers, and section titles against Ghatak, *Optics* (`unit-1` to `unit-4`). Note: in Unit 1, Ghatak's printed Eq. (3.6) on page 3.6 has a textbook misprint (`n₁ sin θ₁ = n₁ sin θ₂`), whereas Fig. 3.5's caption on page 3.5 and Eq. (4.1) on page 4.2 state the intended Snell's law `n₁ sin θ₁ = n₂ sin θ₂`, which we use.
6. **Change 6 (Skill files updated):**
   - Updated `skills/01-schema.md`, `skills/02-derivations.md`, `skills/03-svg-art.md`, `skills/04-questions.md`, and `skills/05-checklist.md` to document `data-part`, `focus`, parallel steps one after another, the summary stage, and using only palette tokens from `01-tokens.css`.

#### Anything that could not be done
- Everything requested in Changes 1 through 6 was completed.
