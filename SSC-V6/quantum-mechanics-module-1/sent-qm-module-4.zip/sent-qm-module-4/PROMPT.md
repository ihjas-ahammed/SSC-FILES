# Quantum Mechanics I — Module IV: The Quantum Harmonic Oscillator and 3D Cartesian Problems

You are making the study deck for Module IV of Quantum Mechanics I (FYUGP BSc Physics Honours, Calicut University, Semester V). The student is an undergraduate in India. English is their second language. Use short sentences and simple words. Explain any hard word in one plain sentence the first time it appears.

You have no file system and no shell. You work from the files in this zip and from this chat. You reply in chat only. Follow `OUTPUT-FORMAT.md`.

## 1. Read these first, in this order

1. This file.
2. `OUTPUT-FORMAT.md`.
3. The skills in `skills/` (`00-START-HERE.md` to `08-definition-recall.md`). They define the card schema, derivation cards, SVG art, questions, plain words and definition recall. Follow them exactly.
4. `example/data-qm-m1.json`. This is the finished Module I. Match its structure, field names and style.

## 2. Scope: Module IV, units 22–25

Syllabus pages 113–114 (`source/syllabus.pdf`). The source is Zettili, *Quantum Mechanics: Concepts and Applications* (Book 2).

| Unit | Content | Source PDF in `source/units/` | Book section |
|---|---|---|---|
| 22 | The harmonic oscillator: energy eigenvalues; energy eigenstates; energy eigenstates in position space (up to the first excited state only); the matrix representation of various operators; expectation values of various operators | `unit-22-harmonic-oscillator.pdf` | Zettili §4.8–4.8.5 (chapter 4) |
| 23 | 3D problems in Cartesian coordinates: general treatment, separation of variables | `unit-23-3d-cartesian-separation-variables.pdf` | Zettili §6.2.1 (chapter 6) |
| 24 | The box potential: rectangular and cubic box potentials; degeneracy | `unit-24-box-potential.pdf` | Zettili §6.2.3 (chapter 6) |
| 25 | The 3D harmonic oscillator: anisotropic and isotropic oscillators; degeneracy | `unit-25-3d-harmonic-oscillator.pdf` | Zettili §6.2.4 (chapter 6) |

Cite Zettili's equation numbers (for example `(4.xxx)`, `(6.xx)`) as printed in the PDFs. Put the section in each sheet's `source` field.

**Pages outside the syllabus.** Use only the content of the section named in your unit's row. Do not write:
- §4.9 (numerical solution of the Schrödinger equation), whose heading is on the last page of unit 22;
- §6.2.2 (the free particle);
- §6.3 (3D problems in spherical coordinates, including the isotropic oscillator in spherical coordinates and the hydrogen atom), which is not in this module.

Do not write Module I, II or III content (wave function, stationary states, wells, step, barrier, Hilbert space, operators, matrices). Do not repeat their glossary entries. When a Module IV card needs an idea from an earlier module (for example the Schrödinger equation, separation of variables in one dimension, the ladder operators from the same section, normalisation), name it in the text and cite its equation number.

## 3. Rules for the content

- **Sources are the only source.** Use the unit PDFs. Do not use any other book or web content. If a fact is not in the PDFs, do not write it.
- **Accuracy.** Every equation, sign, energy, quantum number, degeneracy and result must match the PDF. Re-derive each derivation step yourself before you write it. The energy-level table for the cubic box and for the isotropic oscillator (Zettili Tables 6.1 and 6.2) must match the PDF exactly.
- **Cards.** Start each concept with a plain explanation (what it is, a picture in words, a small example), then the technical statement. Follow `skills/01-schema.md`.
- **Derivations.** One `derivation` card per derived result, with a `setup` SVG (see `skills/02-derivations.md` and `skills/03-svg-art.md`). Ask questions only about the next step. Keep each `note` to one short sentence. For unit 22, write the ladder-operator steps as printed. Do not go beyond the first excited state where the PDF stops there.
- **Pictures.** Use the SVG rules in `skills/03-svg-art.md`. Energy-level pictures: label each level with its energy and quantum numbers. Parabolic potential: label the axes. Box: label the walls and the box length.
- **Quiz questions** (OMR, fill-in, number). Follow `skills/04-questions.md`. Questions are at most about 15 words. Each option is at most about 6 words. Use 3 or 4 options with exactly one correct answer. The `why` is one or two short sentences.
- **Glossary.** Define hard words (for example *harmonic oscillator*, *zero-point energy*, *ladder operator*, *degeneracy*, *separation of variables*, *anisotropic*, *isotropic*) in the glossary, short and plain. Ids start with `qm-m4-`.
- **Settings.** `meta.inlineChecks` false, `meta.autoRevealQuestions` true, `meta.definitionChecks` true, `meta.date` `""`, `meta.sessions` `[]`. The timetable is not filled yet.
- **Cover the syllabus.** Every unit 22–25 has at least one concept card, its derivations and quiz questions. In your reply, note any sub-topic from the syllabus that the PDFs do not cover, and do not invent it.

## 4. Structure of the output

Build one JSON object with the same shape as `example/data-qm-m1.json`: `meta`, `match`, `glossary`, `sections`.
- `meta.title`: "Quantum Mechanics I — Module IV: The Quantum Harmonic Oscillator and 3D Cartesian Problems".
- One section titled "Module IV", with one sheet per unit, IDs `qm-m4-unit-22` to `qm-m4-unit-25`, in order.
- Sheet IDs and card IDs must be unique.

## 5. What to reply

Reply in chat with exactly what `OUTPUT-FORMAT.md` asks for: one fenced `json` block containing the whole Module IV data file, then a short list of anything you could not verify from the PDFs. Then stop.
