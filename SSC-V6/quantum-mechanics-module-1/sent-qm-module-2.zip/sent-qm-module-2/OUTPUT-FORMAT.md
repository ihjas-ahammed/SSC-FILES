# Output format — Quantum Mechanics I, Module II data

You have no file system and no shell. You cannot save files. Your entire reply is in chat.

Reply with exactly this, in this order:

1. One fenced code block labelled `json` containing the complete Module II data file. It must be valid JSON. No comments, no trailing commas, and no text inside the block.
2. A short plain-text list titled `Not verified from the PDFs`. Give one line per claim you could not check against a source PDF (or write `none`).

Nothing else. No preamble, no summary of the content, no extra code blocks.

Checklist before you reply:
- The JSON has keys `meta`, `match`, `glossary`, `sections`, in that order.
- `meta.title` is "Quantum Mechanics I — Module II: The Time-Independent Schrödinger Equation".
- `sections` has exactly one section, titled "Module II", with sheets `qm-m2-unit-6` to `qm-m2-unit-11`, in order.
- Every sheet has a `source` field. Units 6–8 name the Griffiths section. Units 9–11 name the Zettili section.
- Every `mcq` card has `answer` equal to the index of the correct option, and 3 or 4 options.
- Every `derivation` card has a `setup` SVG.
- Every glossary entry used in the text is defined.
