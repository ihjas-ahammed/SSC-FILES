# Quantum Mechanics I — Module III: Mathematical Tools of Quantum Mechanics

You are making the study deck for Module III of Quantum Mechanics I (FYUGP BSc Physics Honours, Calicut University, Semester V). The student is an undergraduate in India. English is their second language. Use short sentences and simple words. Explain any hard word in one plain sentence the first time it appears.

You have no file system and no shell. You work from the files in this zip and from this chat. You reply in chat only. Follow `OUTPUT-FORMAT.md`.

## 1. Read these first, in this order

1. This file.
2. `OUTPUT-FORMAT.md`.
3. The skills in `skills/` (`00-START-HERE.md` to `08-definition-recall.md`). They define the card schema, derivation cards, SVG art, questions, plain words and definition recall. Follow them exactly.
4. `example/data-qm-m1.json`. This is the finished Module I. Match its structure, field names and style.

## 2. Scope: Module III, units 12–21

Syllabus page 113 (`source/syllabus.pdf`). All units are from Zettili, *Quantum Mechanics: Concepts and Applications*, Chapter 2 (Book 2).

| Unit | Content | Source PDF in `source/units/` | Book |
|---|---|---|---|
| 12 | The Hilbert space and wave functions: the linear vector space; the Hilbert space; dimension and basis of a vector space; square-integrable functions; wave functions | `unit-12-hilbert-space-wave-functions.pdf` | Zettili §2.2 |
| 13 | Dirac notation: kets, bras, bra-kets and their properties | `unit-13-dirac-notation.pdf` | Zettili §2.3 |
| 14 | Operators: general definitions, Hermitian adjoint and its properties, Hermitian operators | `unit-14-operators-hermitian-adjoint.pdf` | Zettili §2.4.1–2.4.2 |
| 15 | Commutator algebra | `unit-15-commutator-algebra.pdf` | Zettili §2.4.4 |
| 16 | Uncertainty relation between two operators: general relation and Heisenberg uncertainty relations | `unit-16-uncertainty-two-operators.pdf` | Zettili §2.4.5 |
| 17 | Functions of operators | `unit-17-functions-of-operators.pdf` | Zettili §2.4.6 |
| 18 | Eigenvalues and eigenvectors of an operator (Theorems 2.1–2.5) | `unit-18-eigenvalues-eigenvectors.pdf` | Zettili §2.4.8 |
| 19 | Representation of discrete bases: matrix representation of kets and bras; of operators; change of bases and unitary transformations; matrix representation of the eigenvalue problem | `unit-19-matrix-representation-discrete-bases.pdf` | Zettili §2.5.1–2.5.3 |
| 20 | Representation of continuous bases: general treatment; position representation; momentum representation; connecting position and momentum representations | `unit-20-continuous-basis.pdf` | Zettili §2.6.1–2.6.4 |
| 21 | Matrix and wave mechanics: matrix mechanics; wave mechanics | `unit-21-matrix-wave-mechanics.pdf` | Zettili §2.7 |

Cite Zettili's equation numbers (for example `(2.351)`) as printed in the PDFs. Put the section in each sheet's `source` field.

**Pages outside the syllabus.** Some unit PDFs also contain the start or end of a section the syllabus does not list. Use only the content of the section named in your unit's row. Do not write:
- §2.4.3 (projection operators), which starts on the last page of unit 14;
- §2.4.7 (inverse and unitary operators), which starts on the last page of unit 17;
- §2.4.9 (infinitesimal and finite unitary transformations);
- §2.6.5 (parity operator), which is on the last pages of unit 20 and the first page of unit 21.

Do not write Module I, II or IV content. Module IV (harmonic oscillator, 3D problems, box potential) is NOT in this job. Do not write it. Module II (stationary states, wells, step, barrier) is done. Do not repeat its glossary entries.

When a Module III card needs an idea from Module I or II (for example the wave function, normalisation, expectation value, the Schrödinger equation), name it in the text and cite its equation number from that module.

## 3. Rules for the content

- **Sources are the only source.** Use the unit PDFs. Do not use any other book or web content. If a fact is not in the PDFs, do not write it.
- **Accuracy.** Every equation, sign, definition, theorem and result must match the PDF. Re-derive each derivation step yourself before you write it. Use the theorem numbers printed in the PDF (for example Theorems 2.1–2.5 in unit 18).
- **Cards.** Start each concept with a plain explanation (what it is, a picture in words, a small example), then the technical statement. Follow `skills/01-schema.md`.
- **Derivations.** One `derivation` card per derived result, with a `setup` SVG (see `skills/02-derivations.md` and `skills/03-svg-art.md`). Ask questions only about the next step. Keep each `note` to one short sentence. Use the matrix and bra-ket notation as printed in the PDF.
- **Pictures.** Use the SVG rules in `skills/03-svg-art.md`. For vector spaces, use simple arrows and labelled axes. For matrices, use a small labelled grid. Do not draw anything the PDF does not describe.
- **Quiz questions** (OMR, fill-in, number). Follow `skills/04-questions.md`. Questions are at most about 15 words. Each option is at most about 6 words. Use 3 or 4 options with exactly one correct answer. The `why` is one or two short sentences.
- **Glossary.** Define hard words (for example *Hilbert space*, *ket*, *bra*, *Hermitian operator*, *commutator*, *eigenvalue*, *unitary transformation*, *square-integrable*) in the glossary, short and plain. Ids start with `qm-m3-`.
- **Settings.** `meta.inlineChecks` false, `meta.autoRevealQuestions` true, `meta.definitionChecks` true, `meta.date` `""`, `meta.sessions` `[]`. The timetable is not filled yet.
- **Cover the syllabus.** Every unit 12–21 has at least one concept card, its derivations and quiz questions. In your reply, note any sub-topic from the syllabus that the PDFs do not cover, and do not invent it.

## 4. Structure of the output

Build one JSON object with the same shape as `example/data-qm-m1.json`: `meta`, `match`, `glossary`, `sections`.
- `meta.title`: "Quantum Mechanics I — Module III: Mathematical Tools of Quantum Mechanics".
- One section titled "Module III", with one sheet per unit, IDs `qm-m3-unit-12` to `qm-m3-unit-21`, in order.
- Sheet IDs and card IDs must be unique.

## 5. What to reply

Reply in chat with exactly what `OUTPUT-FORMAT.md` asks for: one fenced `json` block containing the whole Module III data file, then a short list of anything you could not verify from the PDFs. Then stop.
