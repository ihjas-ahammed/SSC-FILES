# Output format — Quantum Mechanics I, Module III data

You have no file system and no shell. You cannot save files. Your entire reply is in chat.

Reply with exactly this, in this order:

1. One fenced code block labelled `json` containing the complete Module III data file. It must be valid JSON. No comments, no trailing commas, and no text inside the block.
2. A short plain-text list titled `Not verified from the PDFs`. Give one line per claim you could not check against a source PDF (or write `none`).

Nothing else. No preamble, no summary of the content, no extra code blocks.

Checklist before you reply:
- The JSON has keys `meta`, `match`, `glossary`, `sections`, in that order.
- `meta.title` is "Quantum Mechanics I — Module III: Mathematical Tools of Quantum Mechanics".
- `sections` has exactly one section, titled "Module III", with sheets `qm-m3-unit-12` to `qm-m3-unit-21`, in order.
- Every sheet has a `source` field naming the Zettili section (for example "Zettili §2.2").
- No content from §2.4.3, §2.4.7, §2.4.9 or §2.6.5 appears in the file.
- Every `mcq` card has `answer` equal to the index of the correct option, and 3 or 4 options.
- Every `derivation` card has a `setup` SVG.
- Every glossary entry used in the text is defined, and every glossary id starts with `qm-m3-`.
