# Complex Analysis I — Module I: Complex Numbers, the Complex Plane and Polar Form

You are making the study deck for Module I of Complex Analysis I (MAT5CJ303, FYUGP BSc Mathematics Honours, Calicut University, Semester V). The student is an undergraduate in India. English is their second language. Use short sentences and simple words. Explain any hard word in one plain sentence the first time it appears.

You have no file system and no shell. You work from the files in this zip and from this chat. You reply in chat only. Follow `OUTPUT-FORMAT.md`.

## 1. Read these first, in this order

1. This file.
2. `OUTPUT-FORMAT.md`.
3. The skills in `skills/` (`00-START-HERE.md` to `08-definition-recall.md`). They define the card schema, derivation cards, SVG art, questions, plain words and definition recall. Follow them exactly.
4. `example/data-qm-m1.json`. This is a finished module of a different subject (Quantum Mechanics I). Use it for structure, field names and style only. Do not copy its content.

## 2. Scope: Module I, units 1–5

The syllabus is `source/syllabus.pdf` (Module I, Sections 1.1–1.5). The source is Zill and Shanahan, *Complex Analysis: A First Course with Applications*, 3rd ed. (Book 1). `source/map.md` gives the page map. The unit PDFs are cut from the book; their printed page numbers are in each page's footer.

| Unit | Content | Source PDF in `source/units/` | Book section (printed pages) |
|---|---|---|---|
| 1 | Complex numbers and their properties | `unit-1-complex-numbers-and-their-properties.pdf` | §1.1 (pp. 3–9) |
| 2 | Complex plane | `unit-2-complex-plane.pdf` | §1.2 (pp. 10–15) |
| 3 | Polar form of complex numbers | `unit-3-polar-form.pdf` | §1.3 (pp. 16–21) |
| 4 | Powers and roots | `unit-4-powers-and-roots.pdf` | §1.4 (pp. 22–26) |
| 5 | Sets of points in the complex plane | `unit-5-sets-of-points-in-complex-plane.pdf` | §1.5 (pp. 27–33) |

Cite the book's equation numbers, definition numbers, example numbers and theorem numbers as printed (for example "Definition 1.1.1", "Example 2", "Equation (3)"). Put the section (for example "Zill & Shanahan §1.3") in each sheet's `source` field.

**Do not write:**
- Anything from Section 2 or later (Module II onward: complex functions, mappings, power functions, limits, analyticity, Cauchy–Riemann equations, harmonic functions, exponential, logarithm, trigonometric and hyperbolic functions). The cuts stop at printed page 33.
- Module V topics (linear mappings, reciprocal functions, branches, complex powers, inverse trigonometric and hyperbolic functions).
- Any exercise or problem that the text does not name. Exercises are not part of the notes. The one exception: if a sentence in the text names an exercise (for example "Problem 55" in Remark (i) of §1.1), print that exercise directly after the naming sentence, as the book prints it.
- Plus Two recall boxes or any Kerala-syllabus material. The Kerala text is not in the sources.

Do not repeat material from other modules. This is the first module, so nothing is repeated.

## 3. Rules for the content

- **Sources are the only source.** Use the unit PDFs. Do not use any other book or web content. If a fact is not in the PDFs, do not write it.
- **Accuracy.** Every equation, sign, modulus, argument, root and result must match the PDF. Re-derive each derivation step yourself before you write it. Keep principal-argument conventions exactly as the book states them.
- **Cards.** Start each concept with a plain explanation (what it is, a picture in words, a small example), then the technical statement. Follow `skills/01-schema.md`.
- **Derivations.** One `derivation` card per derived result (for example the polar form, De Moivre's formula, the nth roots of a complex number), with a `setup` SVG (see `skills/02-derivations.md` and `skills/03-svg-art.md`). Ask questions only about the next step. Keep each `note` to one short sentence.
- **Pictures.** Use the SVG rules in `skills/03-svg-art.md`. For the complex plane, label the real and imaginary axes, the point z, its modulus r and its argument θ. For sets of points, label the centre and the radius, or the boundary and the region.
- **Quiz questions** (OMR, fill-in, number). Follow `skills/04-questions.md`. Questions are at most about 15 words. Each option is at most about 6 words. Use 3 or 4 options with exactly one correct answer. The `why` is one or two short sentences.
- **Glossary.** Define hard words (for example *complex conjugate*, *modulus*, *argument*, *principal argument*, *polar form*, *nth root*, *open set*, *closed set*, *domain*, *boundary*) in the glossary, short and plain. Ids start with `ca-m1-`.
- **Settings.** `meta.inlineChecks` false, `meta.autoRevealQuestions` true, `meta.definitionChecks` true, `meta.date` `""`, `meta.sessions` `[]`.
- **Cover the syllabus.** Every unit 1–5 has at least one concept card, its derivations or worked steps, and quiz questions. In your reply, note any sub-topic of units 1–5 that the PDFs do not cover, and do not invent it.

## 4. Structure of the output

Build one JSON object with the same shape as `example/data-qm-m1.json`: `meta`, `match`, `glossary`, `sections`.
- `meta.title`: "Complex Analysis I — Module I: Complex Numbers, the Complex Plane and Polar Form".
- `meta.subject`: "Complex Analysis I (MAT5CJ303, Sem 5)".
- One section titled "Module I", with one sheet per unit, IDs `ca-m1-unit-1` to `ca-m1-unit-5`, in order.
- Sheet IDs and card IDs must be unique.

## 5. What to reply

Reply in chat with exactly what `OUTPUT-FORMAT.md` asks for: one fenced `json` block containing the whole Module I data file, then a short list of anything you could not verify from the PDFs. Then stop.
