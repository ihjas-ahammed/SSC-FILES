# Output format — Complex Analysis I, Module I data

You have no file system and no shell. You cannot save files. Your entire reply is in chat.

Reply with exactly this, in this order:

1. One fenced code block labelled `json` containing the complete Module I data file. It must be valid JSON. No comments, no trailing commas, and no text inside the block.
2. A short plain-text list titled `Not verified from the PDFs`. Give one line per claim you could not check against a source PDF (or write `none`).

Nothing else. No preamble, no summary of the content, no extra code blocks.

Checklist before you reply:
- The JSON has keys `meta`, `match`, `glossary`, `sections`, in that order.
- `meta.title` is "Complex Analysis I — Module I: Complex Numbers, the Complex Plane and Polar Form".
- `sections` has exactly one section, titled "Module I", with sheets `ca-m1-unit-1` to `ca-m1-unit-5`, in order.
- Every sheet has a `source` field naming the Zill and Shanahan section (for example "Zill & Shanahan §1.3").
- No content from Section 2 or later, and no Module V topic, appears in the file.
- Every `mcq` card has `answer` equal to the index of the correct option, and 3 or 4 options.
- Every `derivation` card has a `setup` SVG.
- Every glossary entry used in the text is defined, and every glossary id starts with `ca-m1-`.
